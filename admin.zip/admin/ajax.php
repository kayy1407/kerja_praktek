<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    exit;
}

$type = $_GET['type'] ?? '';

if ($type === 'pendaftar') {
    $where_clauses = [];
    
    // Filter Keyword
    if (isset($_GET['q']) && !empty($_GET['q'])) {
        $search_keyword = mysqli_real_escape_string($koneksi, $_GET['q']);
        $where_clauses[] = "(nama LIKE '%$search_keyword%' OR asal_sekolah LIKE '%$search_keyword%' OR email LIKE '%$search_keyword%')";
    }
    
    // Filter Status
    if (isset($_GET['s']) && !empty($_GET['s']) && $_GET['s'] != 'Semua') {
        $status_filter = mysqli_real_escape_string($koneksi, $_GET['s']);
        $where_clauses[] = "status = '$status_filter'";
    }
    
    // Filter Kelas
    if (isset($_GET['k']) && !empty($_GET['k']) && $_GET['k'] != 'Semua') {
        $kelas_filter = mysqli_real_escape_string($koneksi, $_GET['k']);
        $where_clauses[] = "kelas LIKE '$kelas_filter %'";
    }
    
    $where_sql = "";
    if (count($where_clauses) > 0) {
        $where_sql = "WHERE " . implode(" AND ", $where_clauses);
    }
    
    $order_sql = "ORDER BY created_at DESC";
    if (isset($_GET['o'])) {
        $sort = $_GET['o'];
        if ($sort == 'Nama A-Z') {
            $order_sql = "ORDER BY nama ASC";
        } elseif ($sort == 'Nama Z-A') {
            $order_sql = "ORDER BY nama DESC";
        }
    }
    
    $query = "SELECT * FROM pendaftar $where_sql $order_sql";
    $result = mysqli_query($koneksi, $query);
    
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)):
            $badge_class = 'badge-warning';
            if ($row['status'] == 'Disetujui') $badge_class = 'badge-success';
            if ($row['status'] == 'Ditolak') $badge_class = 'badge-danger';
            $year = (int)date('Y', strtotime($row['created_at']));
            $cntRes = mysqli_query($koneksi, "SELECT COUNT(*) AS pos FROM pendaftar WHERE YEAR(created_at) = $year AND id <= " . (int)$row['id']);
            $cntRow = $cntRes ? mysqli_fetch_assoc($cntRes) : ['pos' => 1];
            $pos = (int)$cntRow['pos'];
            if ($pos < 1) { $pos = 1; }
            $no_fmt = 'DF-' . $year . '-' . str_pad($pos, 4, '0', STR_PAD_LEFT);
    ?>
        <tr>
            <td>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($row['nama']); ?></div>
                    <div class="sub-text" style="font-size: 12px; color: #666;"><?php echo htmlspecialchars($row['kelas'] ?? '-'); ?></div>
                </div>
            </td>
            <td><?php echo htmlspecialchars($no_fmt); ?></td>
            <td><?php echo date('d M Y', strtotime($row['tanggal_daftar'])); ?></td>
            <td>
                <span class="badge <?php echo $badge_class; ?>"><?php echo $row['status']; ?></span>
            </td>
            <td class="actions" style="white-space: nowrap;">
                <a href="detail-pendaftar.php?id=<?php echo $row['id']; ?>" class="btn btn-outline" title="Detail" style="padding: 0; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </a>
                <?php if ($row['status'] == 'Menunggu'): ?>
                    <a href="proses.php?type=pendaftar&id=<?php echo $row['id']; ?>&action=setujui" class="btn btn-primary" title="Setujui" style="padding: 0; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    </a>
                    <a href="proses.php?type=pendaftar&id=<?php echo $row['id']; ?>&action=tolak" class="btn btn-danger" title="Tolak" style="padding: 0; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                    </a>
                <?php elseif ($row['status'] == 'Disetujui' || $row['status'] == 'Ditolak'): ?>
                    <a href="proses.php?type=pendaftar&id=<?php echo $row['id']; ?>&action=batalkan" class="btn btn-warning" title="Batalkan" style="padding: 0; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>
                    </a>
                <?php endif; ?>
                <?php if ($row['status'] != 'Disetujui'): ?>
                    <a href="proses.php?type=pendaftar&id=<?php echo $row['id']; ?>&action=hapus" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini? Data yang dihapus tidak dapat dikembalikan.')" title="Hapus" style="padding: 0; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                    </a>
                <?php endif; ?>
            </td>
        </tr>
    <?php
        endwhile;
    } else {
        $check_all = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pendaftar");
        $data_all = mysqli_fetch_assoc($check_all);
        
        if ($data_all['total'] == 0) {
            echo '<tr><td colspan="5" style="text-align:center; padding: 40px 20px; color: #64748b;">
                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="opacity: 0.5;"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    <span style="font-size: 14px;">Belum ada pendaftar baru</span>
                </div>
            </td></tr>';
        } else {
            echo '<tr><td colspan="5" style="text-align:center; padding: 20px; color: #666;">
                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="opacity: 0.5;"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="8"></line></svg>
                    <span>Hasil pencarian tidak ditemukan</span>
                </div>
            </td></tr>';
        }
    }

} elseif ($type === 'siswa') {
    $view_kelas = $_GET['view_kelas'] ?? null;
    $search_keyword = isset($_GET['q']) ? mysqli_real_escape_string($koneksi, $_GET['q']) : '';
    
    $where_clause = "WHERE 1=1";
    
    if (!empty($search_keyword)) {
        $where_clause .= " AND (nama LIKE '%$search_keyword%' OR kelas LIKE '%$search_keyword%')";
    }
    
    $query = "SELECT * FROM siswa $where_clause ORDER BY nama ASC";
    $result = mysqli_query($koneksi, $query);
    
    $filteredData = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $k = strtoupper($row['kelas']);
        $is_kelas_12 = (strpos($k, '12') !== false || strpos($k, 'XII') !== false);
        $is_kelas_11 = (strpos($k, '11') !== false || strpos($k, 'XI') !== false);
        
        $current_kelas = 'X';
        if ($is_kelas_12) {
            $current_kelas = 'XII';
        } elseif ($is_kelas_11) {
            $current_kelas = 'XI';
        } else {
            $current_kelas = 'X';
        }
    
        if ($view_kelas && $current_kelas == $view_kelas) {
            $filteredData[] = $row;
        }
    }
    
    if (empty($filteredData)) {
        echo '<tr><td colspan="4" style="text-align:center; padding: 20px; color: #666;">
            <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px;">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="opacity: 0.5;"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="8"></line></svg>
                <span>Hasil pencarian tidak ditemukan</span>
            </div>
        </td></tr>';
    } else {
        foreach ($filteredData as $row) {
            $badge_class = ($row['status'] == 'Aktif') ? 'badge-success' : 'badge-danger';
            echo '<tr>';
            echo '<td><div class="user-info"><div class="name">' . htmlspecialchars($row['nama']) . '</div></div></td>';
            echo '<td>' . htmlspecialchars($row['kelas']) . '</td>';
            echo '<td><span class="badge ' . $badge_class . '">' . $row['status'] . '</span></td>';
            echo '<td class="actions">';
            echo '<a href="detail-siswa.php?id=' . $row['id'] . '" class="btn btn-outline">Detail</a>';
            if ($row['status'] == 'Aktif') {
                echo '<a href="proses.php?type=siswa&id=' . $row['id'] . '&action=nonaktifkan" class="btn btn-danger" onclick="return confirm(\'Apakah Anda yakin ingin menonaktifkan siswa ini?\')">Nonaktifkan</a>';
            } else {
                echo '<a href="proses.php?type=siswa&id=' . $row['id'] . '&action=aktifkan" class="btn btn-primary" onclick="return confirm(\'Apakah Anda yakin ingin mengaktifkan siswa ini?\')">Aktifkan</a>';
            }
            echo '</td>';
            echo '</tr>';
        }
    }

} elseif ($type === 'status') {
    $where_clauses = [];
    
    if (isset($_GET['q']) && !empty($_GET['q'])) {
        $search_keyword = mysqli_real_escape_string($koneksi, $_GET['q']);
        $where_clauses[] = "(nama LIKE '%$search_keyword%' OR asal_sekolah LIKE '%$search_keyword%')";
    }
    
    if (isset($_GET['s']) && !empty($_GET['s']) && $_GET['s'] != 'Semua') {
        $status_filter = mysqli_real_escape_string($koneksi, $_GET['s']);
        $where_clauses[] = "status = '$status_filter'";
    }
    
    $where_sql = "";
    if (count($where_clauses) > 0) {
        $where_sql = "WHERE " . implode(" AND ", $where_clauses);
    }
    
    $query = "SELECT * FROM pendaftar $where_sql ORDER BY created_at DESC";
    $result = mysqli_query($koneksi, $query);
    
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $badge_class = 'badge-warning';
            if ($row['status'] == 'Disetujui') $badge_class = 'badge-success';
            if ($row['status'] == 'Ditolak') $badge_class = 'badge-danger';
            ?>
            <tr>
                <td>
                <div class="user-info">
                    <div class="name"><?php echo htmlspecialchars($row['nama']); ?></div>
                    <div class="email" style="font-size: 12px; color: #666;"><?php echo htmlspecialchars($row['asal_sekolah']); ?> • <?php echo htmlspecialchars($row['kelas'] ?? '-'); ?></div>
                </div>
            </td>
                <td><?php echo date('d M Y', strtotime($row['tanggal_daftar'])); ?></td>
                <td>
                    <span class="badge <?php echo $badge_class; ?>"><?php echo $row['status']; ?></span>
                </td>
            </tr>
            <?php
        }
    } else {
        $check_all = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pendaftar");
        $data_all = mysqli_fetch_assoc($check_all);
        
        if ($data_all['total'] == 0) {
            echo '<tr><td colspan="3" style="text-align:center; padding: 40px 20px; color: #64748b;">
                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="opacity: 0.5;"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    <span style="font-size: 14px;">Belum ada data pendaftar</span>
                </div>
            </td></tr>';
        } else {
            echo '<tr><td colspan="3" style="text-align:center; padding: 40px; color: #9ca3af;">
                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 16px;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="opacity: 0.5;"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <span style="font-size: 14px; font-weight: 500;">Data tidak ditemukan</span>
                </div>
            </td></tr>';
        }
    }
}
?>
