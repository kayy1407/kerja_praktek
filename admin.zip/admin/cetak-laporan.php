<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

// --- LOGIKA FILTER (Sama dengan laporan.php) ---
$periode = isset($_GET['periode']) ? $_GET['periode'] : '12';
$kelas_filter = isset($_GET['kelas']) ? $_GET['kelas'] : 'Semua';

// 1. Hitung Total Siswa Aktif
$query_siswa_aktif = "SELECT COUNT(*) as total FROM siswa WHERE status = 'Aktif'";
$result_siswa_aktif = mysqli_query($koneksi, $query_siswa_aktif);
$row_siswa_aktif = mysqli_fetch_assoc($result_siswa_aktif);
$total_siswa_aktif = $row_siswa_aktif['total'];

// 2. Hitung Total Pendaftar
$query_total_pendaftar = "SELECT COUNT(*) as total FROM pendaftar";
$result_total_pendaftar = mysqli_query($koneksi, $query_total_pendaftar);
$row_total_pendaftar = mysqli_fetch_assoc($result_total_pendaftar);
$total_pendaftar = $row_total_pendaftar['total'];

// 3. Data Tren Pendaftar (DIHAPUS)
// $query_tren = ...;
// $result_tren = ...;

// 4. Data Distribusi Siswa
$where_kelas = "WHERE status = 'Aktif'";

$query_distribusi = "SELECT kelas, COUNT(*) as total
FROM siswa
$where_kelas
GROUP BY kelas
ORDER BY kelas ASC";

$result_distribusi = mysqli_query($koneksi, $query_distribusi);

// Normalisasi data agar semua kelas (X, XI, XII) tetap muncul meski jumlahnya 0
$raw_data = [];
while ($row = mysqli_fetch_assoc($result_distribusi)) {
    $raw_data[$row['kelas']] = $row['total'];
}

// Definisi kelas standar
$standard_classes = ['X (Sepuluh)', 'XI (Sebelas)', 'XII (Dua Belas)'];

// Gabungkan kelas standar dengan kelas yang ada di database (agar kelas non-standar juga muncul)
$all_classes = array_unique(array_merge($standard_classes, array_keys($raw_data)));
sort($all_classes); // Urutkan abjad

$final_distribusi = [];
$total_terfilter = 0;

foreach ($all_classes as $cls) {
    // Logika Filter:
    // Jika filter 'Semua', masukkan semua kelas.
    // Jika filter spesifik (misal 'X'), hanya masukkan yang mengandung string tersebut.
    
    $show_class = false;
    if ($kelas_filter == 'Semua') {
        $show_class = true;
    } elseif ($kelas_filter == 'X' && strpos($cls, 'X') === 0 && strpos($cls, 'XI') !== 0) {
         $show_class = true;
    } elseif ($kelas_filter == 'XI' && strpos($cls, 'XI') === 0 && strpos($cls, 'XII') !== 0) {
         $show_class = true;
    } elseif ($kelas_filter == 'XII' && strpos($cls, 'XII') === 0) {
         $show_class = true;
    }

    if ($show_class) {
        $count = isset($raw_data[$cls]) ? $raw_data[$cls] : 0;
        $final_distribusi[] = [
            'kelas' => $cls,
            'total' => $count
        ];
        $total_terfilter += $count;
    }
}

// Fungsi sederhana untuk ubah nama bulan ke Indonesia
function bulan_indo($str) {
    $bulan_inggris = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $bulan_indo = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return str_ireplace($bulan_inggris, $bulan_indo, $str);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan - MA Darul Fithrah</title>
    <link rel="stylesheet" href="../assets/css/laporan-print.css">
</head>
<body onload="window.print()">

    <!-- Tombol Kembali (Hanya tampil di layar) -->
    <div class="no-print" style="margin-bottom: 20px;">
        <button onclick="window.close()" style="padding: 10px 20px; cursor: pointer;">Tutup / Kembali</button>
    </div>

    <div class="kop-surat">
        <!-- Pastikan path logo benar relative terhadap file ini -->
        <img src="../assets/img/logo.png" alt="Logo" class="kop-logo">
        <div class="kop-text">
            <h1>MA DARUL FITHRAH</h1>
            <h2>MADRASAH ALIYAH</h2>
            <p>Alamat: Kampung Parigi, Desa Ciparay, Kecamatan Ciparay, Kabupaten Bandung, Provinsi Jawa Barat</p>
            <p>Email: ponpestahfidzdarulfithrah@gmail.com | Telp: 0821-2127-2601</p>
        </div>
    </div>

    <div class="laporan-title">
        <h3>LAPORAN DATA PENDAFTAR</h3>
        <p>Periode Data: <?php echo bulan_indo(date('d F Y')); ?></p>
    </div>

    <div class="section-title">Distribusi Siswa per Kelas <?php echo ($kelas_filter != 'Semua') ? "(Filter: $kelas_filter)" : ""; ?></div>
    <table>
        <thead>
            <tr>
                <th style="width: 50px;">No</th>
                <th>Kelas</th>
                <th>Jumlah Siswa</th>
                <th>Persentase</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if (count($final_distribusi) > 0): 
                $no = 1;
                foreach ($final_distribusi as $row):
            ?>
                <tr>
                    <td class="text-center"><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($row['kelas']); ?></td>
                    <td class="text-center"><?php echo $row['total']; ?></td>
                    <td class="text-center">
                        <?php 
                        $persen = ($total_terfilter > 0) ? ($row['total'] / $total_terfilter) * 100 : 0;
                        echo number_format($persen, 1) . '%'; 
                        ?>
                    </td>
                </tr>
            <?php 
                endforeach; 
            ?>
                <tr style="font-weight: bold; background-color: #f0f0f0;">
                    <td colspan="2" class="text-center">Total</td>
                    <td class="text-center"><?php echo $total_terfilter; ?></td>
                    <td class="text-center"><?php echo ($total_terfilter > 0) ? '100%' : '0%'; ?></td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center">Tidak ada data siswa aktif.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <div class="stats-summary" style="margin-top: 30px; margin-bottom: 30px;">
        <div class="stat-item">
            <h4>Total Siswa Aktif</h4>
            <span><?php echo $total_siswa_aktif; ?></span>
        </div>
        <div class="stat-item">
            <h4>Total Pendaftar (Keseluruhan)</h4>
            <span><?php echo $total_pendaftar; ?></span>
        </div>
    </div>

    <div class="ttd-area">
        <p>Jakarta, <?php echo bulan_indo(date('d F Y')); ?></p>
        <p>Kepala Madrasah,</p>
        <div class="ttd-space"></div>
        <p><strong>Dra. Euis Nurhayati., S.Pd.</strong></p>
        <p>NIP. ...........................</p>
    </div>

</body>
</html>