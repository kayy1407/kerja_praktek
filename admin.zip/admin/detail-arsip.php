<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

$tahun = $_GET['tahun'] ?? '';
if (empty($tahun)) {
    header("Location: arsip-data.php");
    exit;
}

// Ambil data arsip
$query_pendaftar = "SELECT * FROM arsip_pendaftar WHERE tahun_ajaran = '$tahun' ORDER BY nama ASC";
$result_pendaftar = mysqli_query($koneksi, $query_pendaftar);

// Tidak menampilkan data siswa pada halaman detail arsip; fokus pada pendaftar saja


?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Arsip <?php echo htmlspecialchars($tahun); ?> - MA Darul Fithrah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../assets/css/detail-arsip.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../assets/css/custom-admin.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="sidebar-overlay" onclick="document.querySelector('.sidebar').classList.remove('active'); document.querySelector('.sidebar-overlay').classList.remove('active');"></div>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <a href="#" class="brand">
                <img src="../assets/img/logo.png" alt="Logo">
                <div class="brand-text">
                    <span class="brand-title">MA Darul Fithrah</span>
                    <span class="brand-subtitle">Madrasah Aliyah</span>
                </div>
            </a>
            <ul class="nav-menu">
                <li>
                    <a href="dashboard.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="data-pendaftar.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
                        Pendaftar Baru
                    </a>
                </li>
                <li>
                    <a href="status-penerimaan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                        Status Penerimaan
                    </a>
                </li>
                <li>
                    <a href="data-siswa.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        Data Siswa
                    </a>
                </li>
                <li>
                    <a href="laporan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        Laporan
                    </a>
                </li>
                <li>
                    <a href="arsip-data.php" class="nav-link active">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>
                        Arsip Data
                    </a>
                </li>
                
                <li>
                    <a href="ganti-password.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        Ganti Password
                    </a>
                </li>
                <li>
                    <a href="logout.php" class="nav-link logout-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Logout
                    </a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <button class="sidebar-toggle" onclick="document.querySelector('.sidebar').classList.add('active'); document.querySelector('.sidebar-overlay').classList.add('active');">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                </button>
                <div class="header-title">
                    <a href="arsip-data.php" class="btn-back">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"></path><polyline points="12 19 5 12 12 5"></polyline></svg>
                        Kembali
                    </a>
                    <h1>Arsip Tahun <?php echo htmlspecialchars($tahun); ?></h1>
                </div>
            </header>

            <?php
            $detail = null;
            if (isset($_GET['id'])) {
                $id = mysqli_real_escape_string($koneksi, $_GET['id']);
                $q_detail = "SELECT * FROM arsip_pendaftar WHERE id = '$id' AND tahun_ajaran = '$tahun' LIMIT 1";
                $r_detail = mysqli_query($koneksi, $q_detail);
                $detail = mysqli_fetch_assoc($r_detail);
            }
            ?>

            <?php if ($detail): ?>
            <div class="detail-card" style="margin-top: 0;">
                <div class="detail-header">
                    <div class="detail-left">
                        <div class="detail-title">Detail Pendaftar (Arsip)</div>
                        <div class="user-chip">
                            <div class="avatar"><?php echo strtoupper(substr($detail['nama'] ?? '-', 0, 1)); ?></div>
                            <div class="user-text">
                                <div class="user-name"><?php echo htmlspecialchars($detail['nama'] ?? '-'); ?></div>
                                <div class="user-sub"><?php echo htmlspecialchars($detail['nisn'] ?? '-'); ?></div>
                            </div>
                        </div>
                    </div>
                    <?php
                        $status = $detail['status'] ?? 'Menunggu';
                        $badge_class = 'badge-warning';
                        if ($status == 'Disetujui' || $status == 'Diterima') {
                            $badge_class = 'badge-success';
                        } elseif ($status == 'Ditolak') {
                            $badge_class = 'badge-danger';
                        }
                    ?>
                    <span class="badge <?php echo $badge_class; ?>" style="white-space: nowrap;"><?php echo $status; ?></span>
                </div>
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-label">Nama</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['nama'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">NISN</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['nisn'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Jenis Kelamin</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['jenis_kelamin'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Tempat, Tanggal Lahir</div>
                        <div class="detail-value">
                            <?php
                                $tmp = $detail['tempat_lahir'] ?? '';
                                $tgl = isset($detail['tanggal_lahir']) && $detail['tanggal_lahir'] ? date('d M Y', strtotime($detail['tanggal_lahir'])) : '-';
                                echo htmlspecialchars($tmp ? $tmp . ', ' . $tgl : $tgl);
                            ?>
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Agama</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['agama'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">No. HP</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['no_hp'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Email</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['email'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <div class="detail-label">Alamat Lengkap</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['alamat'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Kelas Dituju</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['kelas'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Asal Sekolah</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['asal_sekolah'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <div class="detail-label">Sumber Informasi</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['sumber_info'] ?? '-'); ?></div>
                    </div>
                </div>
            </div>
            <div class="detail-card">
                <div class="detail-header">
                    <div class="detail-title">Data Orang Tua</div>
                </div>
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-label">Nama Ayah</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['nama_ayah'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Pekerjaan Ayah</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['pekerjaan_ayah'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Nama Ibu</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['nama_ibu'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Pekerjaan Ibu</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['pekerjaan_ibu'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <div class="detail-label">No. HP Orang Tua</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['no_hp_ortu'] ?? '-'); ?></div>
                    </div>
                </div>
            </div>
            <div class="detail-card">
                <div class="detail-header">
                    <div class="detail-title">Informasi Arsip</div>
                </div>
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-label">Tahun Ajaran</div>
                        <div class="detail-value"><?php echo htmlspecialchars($detail['tahun_ajaran'] ?? $tahun); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Tanggal Arsip</div>
                        <div class="detail-value">
                            <?php
                                echo isset($detail['tgl_arsip']) && $detail['tgl_arsip'] ? date('d M Y H:i', strtotime($detail['tgl_arsip'])) : '-';
                            ?>
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Tanggal Daftar</div>
                        <div class="detail-value">
                            <?php
                                echo isset($detail['tanggal_daftar']) && $detail['tanggal_daftar'] ? date('d M Y', strtotime($detail['tanggal_daftar'])) : '-';
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="detail-card">
                <div class="detail-header">
                    <div class="detail-title">Dokumen Pendukung</div>
                </div>
                <div class="document-section">
                    <div class="document-grid">
                        <?php if (isset($detail['ijazah']) && $detail['ijazah']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($detail['ijazah']); ?>" class="document-preview" alt="Ijazah">
                            <div class="document-label">Ijazah/SKL</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($detail['ijazah']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if (isset($detail['akta_kelahiran']) && $detail['akta_kelahiran']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($detail['akta_kelahiran']); ?>" class="document-preview" alt="Akta">
                            <div class="document-label">Akta Kelahiran</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($detail['akta_kelahiran']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if (isset($detail['kartu_keluarga']) && $detail['kartu_keluarga']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($detail['kartu_keluarga']); ?>" class="document-preview" alt="KK">
                            <div class="document-label">Kartu Keluarga</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($detail['kartu_keluarga']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if (isset($detail['ktp_ortu']) && $detail['ktp_ortu']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($detail['ktp_ortu']); ?>" class="document-preview" alt="KTP Ortu">
                            <div class="document-label">KTP Orang Tua</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($detail['ktp_ortu']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if (isset($detail['kartu_bantuan']) && $detail['kartu_bantuan']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($detail['kartu_bantuan']); ?>" class="document-preview" alt="KIP/PKH">
                            <div class="document-label">KIP (Jika Ada)</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($detail['kartu_bantuan']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if (isset($detail['pas_foto']) && $detail['pas_foto']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($detail['pas_foto']); ?>" class="document-preview" alt="Pas Foto">
                            <div class="document-label">Pas Foto</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($detail['pas_foto']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if (isset($detail['surat_sehat']) && $detail['surat_sehat']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($detail['surat_sehat']); ?>" class="document-preview" alt="Surat Sehat">
                            <div class="document-label">Surat Keterangan Sehat</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($detail['surat_sehat']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="action-buttons">
                <a href="detail-arsip.php?tahun=<?php echo urlencode($tahun); ?>" class="back-link" title="Tutup detail dan kembali ke daftar">Tutup</a>
            </div>
            <?php endif; ?>

            <?php if (!$detail): ?>
                <div id="pendaftar" class="tab-content active" style="display: block;">
                    <div class="table-card">
                        <div class="table-scroll">
                            <table class="table">
                                <colgroup>
                                    <col style="width: 60px;">
                                    <col class="col-name">
                                    <col>
                                    <col>
                                    <col class="col-status" style="width: 120px;">
                                    <col class="col-actions" style="width: 140px;">
                                </colgroup>
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Lengkap</th>
                                        <th>NISN</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (mysqli_num_rows($result_pendaftar) > 0): ?>
                                        <?php $no = 1; while($row = mysqli_fetch_assoc($result_pendaftar)): ?>
                                        <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td>
                                                <div class="user-info">
                                                    <div class="name"><?php echo htmlspecialchars($row['nama'] ?? '-'); ?></div>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($row['nisn'] ?? '-'); ?></td>
                                            <td><?php echo htmlspecialchars($row['jenis_kelamin'] ?? '-'); ?></td>
                                            <td>
                                                <?php
                                                $status = $row['status'] ?? 'Menunggu';
                                                $badge_class = 'badge-warning';
                                                
                                                if ($status == 'Disetujui' || $status == 'Diterima') {
                                                    $badge_class = 'badge-success';
                                                } elseif ($status == 'Ditolak') {
                                                    $badge_class = 'badge-danger';
                                                }
                                                ?>
                                                <span class="badge <?php echo $badge_class; ?>" style="white-space: nowrap;"><?php echo $status; ?></span>
                                            </td>
                                            <td class="actions">
                                            <a href="detail-arsip.php?tahun=<?php echo urlencode($tahun); ?>&id=<?php echo urlencode($row['id']); ?>" class="btn btn-primary" title="Lihat Detail">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                            </a>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" style="text-align: center; padding: 40px;">
                                                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px; color: #64748b;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="opacity: 0.5;"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                                                    <span>Tidak ada data pendaftar untuk tahun ini.</span>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </main>
    </div>
</body>
</html>
