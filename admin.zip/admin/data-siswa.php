<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

// Auto-cleanup: Jika tabel pendaftar kosong, pastikan tabel siswa juga kosong
// Ini untuk memastikan konsistensi data sesuai permintaan user
$cek_pendaftar = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pendaftar");
$data_pendaftar = mysqli_fetch_assoc($cek_pendaftar);
if ($data_pendaftar['total'] == 0) {
    mysqli_query($koneksi, "TRUNCATE TABLE siswa");
}

// Filter Pencarian
$where_clause = "WHERE 1=1";
$search_keyword = "";

if (isset($_GET['q']) && !empty($_GET['q'])) {
    $search_keyword = mysqli_real_escape_string($koneksi, $_GET['q']);
    $where_clause .= " AND (nama LIKE '%$search_keyword%' OR kelas LIKE '%$search_keyword%')";
}

// Ambil data siswa
$query = "SELECT * FROM siswa $where_clause ORDER BY nama ASC";
$result = mysqli_query($koneksi, $query);

$kelas10 = [];
$kelas11 = [];
$kelas12 = [];

while ($row = mysqli_fetch_assoc($result)) {
    $k = strtoupper($row['kelas']);
    // Logika pengelompokan kelas
    if (strpos($k, '12') !== false || strpos($k, 'XII') !== false) {
        $kelas12[] = $row;
    } elseif (strpos($k, '11') !== false || strpos($k, 'XI') !== false) {
        $kelas11[] = $row;
    } else {
        // Default ke kelas 10 jika mengandung 10, X, atau tidak terdefinisi (anak baru biasanya kelas 10)
        $kelas10[] = $row;
    }
}

// Fungsi untuk render tabel
function renderTable($data, $kelasTitle, $kelasSlug, $limit = 0) {
    $count = count($data);
    $displayData = ($limit > 0) ? array_slice($data, 0, $limit) : $data;

    echo '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">';
    echo '<div style="display: flex; align-items: center; gap: 10px;">';
    echo '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: #0e1b4d;"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>';
    echo '<h3 style="margin: 0; font-size: 18px; color: #0e1b4d; font-weight: 600;">' . $kelasTitle . '</h3>';
    echo '</div>';
    
    echo '<div style="display: flex; align-items: center; gap: 15px;">';
    
    // Search Form - Hanya tampilkan jika sedang mode lihat semua (limit = 0)
    if ($limit == 0) {
        $current_q = isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '';
        echo '<form action="" method="GET" style="margin: 0;">';
        if (isset($_GET['view_kelas'])) {
            echo '<input type="hidden" name="view_kelas" value="' . htmlspecialchars($_GET['view_kelas']) . '">';
        }
        echo '<div style="position: relative;">';
        echo '<input type="text" id="search-input" name="q" placeholder="Cari siswa..." value="' . $current_q . '" data-kelas="' . $kelasSlug . '" style="padding: 8px 32px 8px 12px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 14px; width: 200px; outline: none;">';
        echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); color: #94a3b8;"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>';
        echo '</div>';
        echo '</form>';
    }

    if ($limit > 0) {
        echo '<a href="data-siswa.php?view_kelas=' . $kelasSlug . '" style="color: #009688; text-decoration: none; font-size: 14px; font-weight: 600;">Lihat Semua</a>';
    }
    
    echo '</div>';
    echo '</div>';
    echo '<div class="table-card" style="margin-bottom: 32px;">';
    echo '<div class="table-scroll">';
    echo '<table class="table">';
    echo '<colgroup>';
    echo '<col class="col-name">';
    echo '<col class="col-class">';
    echo '<col class="col-status">';
    echo '<col class="col-actions">';
    echo '</colgroup>';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Nama</th>';
    echo '<th>Kelas</th>';
    echo '<th>Status</th>';
    echo '<th>Aksi</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody id="table-body-' . $kelasSlug . '">';
    
    if (empty($displayData)) {
        echo '<tr><td colspan="4" style="text-align:center; padding: 20px; color: #666;">Tidak ada data siswa di kelas ini.</td></tr>';
    } else {
        foreach ($displayData as $row) {
            $badge_class = ($row['status'] == 'Aktif') ? 'badge-success' : 'badge-danger';
            echo '<tr>';
            echo '<td>';
            echo '<div class="user-info">';
            echo '<div class="name">' . htmlspecialchars($row['nama']) . '</div>';
            echo '</div>';
            echo '</td>';
            echo '<td>' . htmlspecialchars($row['kelas']) . '</td>';
            echo '<td><span class="badge ' . $badge_class . '">' . $row['status'] . '</span></td>';
            echo '<td class="actions">';
            echo '<a href="detail-siswa.php?id=' . $row['id'] . '" class="btn btn-outline">Detail</a>';
            
            if ($row['status'] == 'Aktif') {
                echo '<a href="proses.php?type=siswa&id=' . $row['id'] . '&action=nonaktifkan" class="btn btn-danger" onclick="return confirm(\'Apakah Anda yakin ingin menonaktifkan siswa ini?\')">Nonaktifkan</a>';
            } else {
                echo '<a href="proses.php?type=siswa&id=' . $row['id'] . '&action=hapus" class="btn btn-danger" onclick="return confirm(\'PERINGATAN: Menghapus siswa ini juga akan menghapus data pendaftarannya secara permanen. Apakah Anda yakin?\')">Hapus</a>';
            }
            
            echo '</td>';
            echo '</tr>';
        }
    }
    
    echo '</tbody>';
    echo '</table>';
    echo '</div>';
    echo '</div>';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa - MA Darul Fithrah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../assets/css/custom-admin.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="sidebar-overlay" onclick="document.querySelector('.sidebar').classList.remove('active'); document.querySelector('.sidebar-overlay').classList.remove('active');"></div>
    <div class="admin-container">
        <aside class="sidebar">
            <a href="#" class="brand">
                <img src="../assets/img/logo.png" alt="Logo">
                <div class="brand-text">
                    <span class="brand-title">MA Darul Fithrah</span>
                    <span class="brand-subtitle">Madrasah Aliyah</span>
                </div>
            </a>
            <ul class="nav-menu">
                <li>
                    <a href="dashboard.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="data-pendaftar.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
                        Pendaftar Baru
                    </a>
                </li>
                <li>
                    <a href="status-penerimaan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                        Status Penerimaan
                    </a>
                </li>
                <li>
                    <a href="data-siswa.php" class="nav-link active">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        Data Siswa
                    </a>
                </li>
                <li>
                    <a href="laporan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        Laporan
                    </a>
                </li>
                <li>
                    <a href="arsip-data.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>
                        Arsip Data
                    </a>
                </li>
                <li>
                    <a href="ganti-password.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        Ganti Password
                    </a>
                </li>
                <li>
                    <a href="logout.php" class="nav-link logout-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Logout
                    </a>
                </li>
            </ul>
        </aside>

        <main class="main-content">
            <header class="header">
                <div style="display: flex; align-items: center;">
                    <button class="sidebar-toggle" onclick="document.querySelector('.sidebar').classList.add('active'); document.querySelector('.sidebar-overlay').classList.add('active');">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                    </button>
                    <div class="header-title">
                        <?php 
                        $view_kelas = $_GET['view_kelas'] ?? null;
                        if ($view_kelas) {
                            echo '<h1>Data Lengkap Siswa Kelas ' . htmlspecialchars($view_kelas) . '</h1>';
                        } else {
                            echo '<h1>Data Siswa</h1>';
                        }
                        ?>
                        <p>Daftar siswa aktif pada MA Darul Fithrah</p>
                    </div>
                </div>
            </header>



            <?php
            $view_kelas = $_GET['view_kelas'] ?? null;

            if ($view_kelas) {
                // Tampilkan hanya satu tabel kelas secara lengkap
                echo '<a href="data-siswa.php" class="back-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg> Kembali</a>';

                if ($view_kelas == 'X') {
                    renderTable($kelas10, "Kelas X", 'X', 0);
                } elseif ($view_kelas == 'XI') {
                    renderTable($kelas11, "Kelas XI", 'XI', 0);
                } elseif ($view_kelas == 'XII') {
                    renderTable($kelas12, "Kelas XII", 'XII', 0);
                }
            } else {
                // Tampilkan semua tabel dengan limit 5 data
                renderTable($kelas10, "Kelas X", 'X', 5);
                renderTable($kelas11, "Kelas XI", 'XI', 5);
                renderTable($kelas12, "Kelas XII", 'XII', 5);
            }
            ?>

        </main>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('search-input');
        
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const query = this.value;
                const kelas = this.getAttribute('data-kelas');
                const tbody = document.getElementById('table-body-' + kelas);
                
                // Fetch data
                fetch(`ajax.php?type=siswa&q=${encodeURIComponent(query)}&view_kelas=${encodeURIComponent(kelas)}`)
                    .then(response => response.text())
                    .then(html => {
                        tbody.innerHTML = html;
                    })
                    .catch(error => console.error('Error:', error));
            });

            // Prevent form submission on Enter
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                }
            });
        }
    });
    </script>
</body>
</html>