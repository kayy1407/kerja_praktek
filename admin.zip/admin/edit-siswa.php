<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: data-siswa.php');
    exit;
}

$id = mysqli_real_escape_string($koneksi, $_GET['id']);

// 1. Ambil data siswa
$query_siswa = "SELECT * FROM siswa WHERE id = '$id'";
$result_siswa = mysqli_query($koneksi, $query_siswa);
$siswa = mysqli_fetch_assoc($result_siswa);

if (!$siswa) {
    echo "<script>alert('Data siswa tidak ditemukan!'); window.location.href='data-siswa.php';</script>";
    exit;
}

// 2. Ambil data pendaftar yang sesuai (berdasarkan nama dan alamat)
$nama = mysqli_real_escape_string($koneksi, $siswa['nama']);
$alamat = mysqli_real_escape_string($koneksi, $siswa['alamat']);

// Cari pendaftar yang cocok, ambil yang paling baru
$query_pendaftar = "SELECT * FROM pendaftar WHERE nama = '$nama' AND alamat = '$alamat' ORDER BY id DESC LIMIT 1";
$result_pendaftar = mysqli_query($koneksi, $query_pendaftar);
$pendaftar = mysqli_fetch_assoc($result_pendaftar);

// 3. Gabungkan data
$data = $siswa;
if ($pendaftar) {
    foreach ($pendaftar as $key => $value) {
        if (!array_key_exists($key, $data)) {
            $data[$key] = $value;
        }
    }
}

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data form
    $nama_lengkap = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $nisn = mysqli_real_escape_string($koneksi, $_POST['nisn']);
    $jenis_kelamin = mysqli_real_escape_string($koneksi, $_POST['jenis_kelamin']);
    $tempat_lahir = mysqli_real_escape_string($koneksi, $_POST['tempat_lahir']);
    $tanggal_lahir = mysqli_real_escape_string($koneksi, $_POST['tanggal_lahir']);
    $agama = mysqli_real_escape_string($koneksi, $_POST['agama']);
    $no_hp = mysqli_real_escape_string($koneksi, $_POST['no_hp']);
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    $alamat_lengkap = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $asal_sekolah = mysqli_real_escape_string($koneksi, $_POST['asal_sekolah']);
    $nama_ayah = mysqli_real_escape_string($koneksi, $_POST['nama_ayah']);
    $pekerjaan_ayah = mysqli_real_escape_string($koneksi, $_POST['pekerjaan_ayah']);
    $nama_ibu = mysqli_real_escape_string($koneksi, $_POST['nama_ibu']);
    $pekerjaan_ibu = mysqli_real_escape_string($koneksi, $_POST['pekerjaan_ibu']);
    $no_hp_ortu = mysqli_real_escape_string($koneksi, $_POST['no_hp_ortu']);
    $kelas_tujuan = mysqli_real_escape_string($koneksi, $_POST['kelas']);
    $sumber_info = mysqli_real_escape_string($koneksi, $_POST['sumber_info']);
    
    // Update Siswa Table
    $query_update_siswa = "UPDATE siswa SET 
        nama = '$nama_lengkap', 
        nisn = '$nisn',
        kelas = '$kelas_tujuan', 
        alamat = '$alamat_lengkap' 
        WHERE id = '$id'";
        
    $update_siswa = mysqli_query($koneksi, $query_update_siswa);
    
    // Update Pendaftar Table (If exists)
    if ($pendaftar) {
        $pendaftar_id = $pendaftar['id'];
        
        // Handle File Uploads (Only if new file uploaded)
        $upload_dir = '../public/uploads/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        
        function handleUpload($file_input, $prefix, $old_file) {
            global $upload_dir;
            if (isset($_FILES[$file_input]) && $_FILES[$file_input]['error'] == 0) {
                $ext = pathinfo($_FILES[$file_input]['name'], PATHINFO_EXTENSION);
                $filename = $prefix . '_' . time() . '_' . rand(100, 999) . '.' . $ext;
                move_uploaded_file($_FILES[$file_input]['tmp_name'], $upload_dir . $filename);
                return $filename;
            }
            return $old_file;
        }
        
        $pas_foto = handleUpload('pas_foto', 'foto', $pendaftar['pas_foto']);
        $kartu_keluarga = handleUpload('kartu_keluarga', 'kk', $pendaftar['kartu_keluarga']);
        $akta_kelahiran = handleUpload('akta_kelahiran', 'akta', $pendaftar['akta_kelahiran']);
        $ijazah = handleUpload('ijazah', 'ijazah', $pendaftar['ijazah']);
        $kartu_bantuan = handleUpload('kartu_bantuan', 'kip', $pendaftar['kartu_bantuan']);
        $ktp_ortu = handleUpload('ktp_ortu', 'ktp_ortu', $pendaftar['ktp_ortu'] ?? '');
        $surat_sehat = handleUpload('surat_sehat', 'surat_sehat', $pendaftar['surat_sehat'] ?? '');
        
        $query_update_pendaftar = "UPDATE pendaftar SET 
            nama = '$nama_lengkap',
            nisn = '$nisn',
            jenis_kelamin = '$jenis_kelamin',
            tempat_lahir = '$tempat_lahir',
            tanggal_lahir = '$tanggal_lahir',
            agama = '$agama',
            no_hp = '$no_hp',
            email = '$email',
            alamat = '$alamat_lengkap',
            asal_sekolah = '$asal_sekolah',
            nama_ayah = '$nama_ayah',
            pekerjaan_ayah = '$pekerjaan_ayah',
            nama_ibu = '$nama_ibu',
            pekerjaan_ibu = '$pekerjaan_ibu',
            no_hp_ortu = '$no_hp_ortu',
            kelas = '$kelas_tujuan',
            sumber_info = '$sumber_info',
            pas_foto = '$pas_foto',
            kartu_keluarga = '$kartu_keluarga',
            akta_kelahiran = '$akta_kelahiran',
            ijazah = '$ijazah',
            kartu_bantuan = '$kartu_bantuan',
            ktp_ortu = '$ktp_ortu',
            surat_sehat = '$surat_sehat'
            WHERE id = '$pendaftar_id'";
            
        mysqli_query($koneksi, $query_update_pendaftar);
    }
    
    if ($update_siswa) {
        echo "<script>alert('Data siswa berhasil diperbarui!'); window.location.href='detail-siswa.php?id=$id';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data: " . mysqli_error($koneksi) . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Data Siswa - MA Darul Fithrah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../assets/css/custom-admin.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="sidebar-overlay" onclick="document.querySelector('.sidebar').classList.remove('active'); document.querySelector('.sidebar-overlay').classList.remove('active');"></div>
    <div class="admin-container">
        <aside class="sidebar">
            <a href="#" class="brand">
                <img src="../assets/img/logo.png" alt="Logo">
                <div class="brand-text">
                    <span class="brand-title">MA Darul Fithrah</span>
                    <span class="brand-subtitle">Madrasah Aliyah</span>
                </div>
            </a>
            <ul class="nav-menu">
                <li>
                    <a href="dashboard.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="data-pendaftar.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
                        Pendaftar Baru
                    </a>
                </li>
                <li>
                    <a href="status-penerimaan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                        Status Penerimaan
                    </a>
                </li>
                <li>
                    <a href="data-siswa.php" class="nav-link active">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        Data Siswa
                    </a>
                </li>
                <li>
                    <a href="laporan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        Laporan
                    </a>
                </li>
                <li>
                    <a href="arsip-data.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>
                        Arsip Data
                    </a>
                </li>
                <li>
                    <a href="ganti-password.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        Ganti Password
                    </a>
                </li>
                <li>
                    <a href="logout.php" class="nav-link logout-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Logout
                    </a>
                </li>
            </ul>
        </aside>

        <main class="main-content">
            <header class="header">
                <button class="sidebar-toggle" onclick="document.querySelector('.sidebar').classList.add('active'); document.querySelector('.sidebar-overlay').classList.add('active');">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                </button>
                <div class="header-title">
                    <h1>Ubah Data Siswa</h1>
                    <p>Perbarui informasi data siswa</p>
                </div>
            </header>
            
            <a href="detail-siswa.php?id=<?php echo $id; ?>" class="btn btn-outline" style="display: inline-flex; align-items: center; gap: 8px; margin-bottom: 24px; border: 1px solid #e5e7eb; background: white; color: #6b7280;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                Kembali
            </a>

            <form class="form-card" action="" method="POST" enctype="multipart/form-data">
                <div class="section-title">Data Pribadi Siswa</div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" name="nama_lengkap" value="<?php echo htmlspecialchars($data['nama']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>NISN</label>
                        <input type="text" name="nisn" value="<?php echo htmlspecialchars($data['nisn'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <select name="jenis_kelamin" required>
                            <option value="">Pilih jenis kelamin</option>
                            <option value="Laki-laki" <?php echo (isset($data['jenis_kelamin']) && $data['jenis_kelamin'] == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option>
                            <option value="Perempuan" <?php echo (isset($data['jenis_kelamin']) && $data['jenis_kelamin'] == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" value="<?php echo htmlspecialchars($data['tempat_lahir'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" value="<?php echo htmlspecialchars($data['tanggal_lahir'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Agama</label>
                        <input type="text" name="agama" value="<?php echo htmlspecialchars($data['agama'] ?? 'Islam'); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label>Nomor HP/WA</label>
                        <input type="tel" name="no_hp" value="<?php echo htmlspecialchars($data['no_hp'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($data['email'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Asal Sekolah (SMP/MTs)</label>
                        <input type="text" name="asal_sekolah" value="<?php echo htmlspecialchars($data['asal_sekolah'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group full-width">
                        <label>Alamat Lengkap</label>
                        <textarea name="alamat" rows="3" required><?php echo htmlspecialchars($data['alamat']); ?></textarea>
                    </div>
                </div>

                <div class="section-title" style="margin-top: 32px;">Data Orang Tua/Wali</div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Nama Ayah</label>
                        <input type="text" name="nama_ayah" value="<?php echo htmlspecialchars($data['nama_ayah'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Pekerjaan Ayah</label>
                        <input type="text" name="pekerjaan_ayah" value="<?php echo htmlspecialchars($data['pekerjaan_ayah'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Nama Ibu</label>
                        <input type="text" name="nama_ibu" value="<?php echo htmlspecialchars($data['nama_ibu'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Pekerjaan Ibu</label>
                        <input type="text" name="pekerjaan_ibu" value="<?php echo htmlspecialchars($data['pekerjaan_ibu'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group full-width">
                        <label>Nomor HP/WA Orang Tua</label>
                        <input type="tel" name="no_hp_ortu" value="<?php echo htmlspecialchars($data['no_hp_ortu'] ?? ''); ?>" required>
                    </div>
                </div>

                <div class="section-title" style="margin-top: 32px;">Pilihan Program</div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Kelas</label>
                        <select name="kelas" required>
                            <option value="">Pilih kelas</option>
                            <option value="X (Sepuluh)" <?php echo ($data['kelas'] == 'X (Sepuluh)') ? 'selected' : ''; ?>>X (Sepuluh)</option>
                            <option value="XI (Sebelas)" <?php echo ($data['kelas'] == 'XI (Sebelas)') ? 'selected' : ''; ?>>XI (Sebelas)</option>
                            <option value="XII (Dua Belas)" <?php echo ($data['kelas'] == 'XII (Dua Belas)') ? 'selected' : ''; ?>>XII (Dua Belas)</option>
                        </select>
                    </div>
                    <div class="form-group full-width">
                        <label>Sumber Informasi</label>
                        <select name="sumber_info" required>
                            <option value="">Pilih sumber informasi</option>
                            <option value="Facebook" <?php echo (isset($data['sumber_info']) && $data['sumber_info'] == 'Facebook') ? 'selected' : ''; ?>>Facebook</option>
                            <option value="Instagram" <?php echo (isset($data['sumber_info']) && $data['sumber_info'] == 'Instagram') ? 'selected' : ''; ?>>Instagram</option>
                            <option value="Website" <?php echo (isset($data['sumber_info']) && $data['sumber_info'] == 'Website') ? 'selected' : ''; ?>>Website</option>
                            <option value="Teman/Kerabat" <?php echo (isset($data['sumber_info']) && $data['sumber_info'] == 'Teman/Kerabat') ? 'selected' : ''; ?>>Teman/Kerabat</option>
                            <option value="Spanduk/Brosur" <?php echo (isset($data['sumber_info']) && $data['sumber_info'] == 'Spanduk/Brosur') ? 'selected' : ''; ?>>Spanduk/Brosur</option>
                            <option value="Lainnya" <?php echo (isset($data['sumber_info']) && $data['sumber_info'] == 'Lainnya') ? 'selected' : ''; ?>>Lainnya</option>
                        </select>
                    </div>
                </div>

                <div class="section-title" style="margin-top: 32px;">Update Berkas (Opsional)</div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Pas Foto</label>
                        <input type="file" name="pas_foto" accept=".jpg,.jpeg,.png">
                        <?php if (isset($data['pas_foto']) && $data['pas_foto']): ?>
                        <div class="current-file">File saat ini: <a href="../public/uploads/<?php echo $data['pas_foto']; ?>" target="_blank">Lihat</a></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>Kartu Keluarga</label>
                        <input type="file" name="kartu_keluarga" accept=".jpg,.jpeg,.png,.pdf">
                        <?php if (isset($data['kartu_keluarga']) && $data['kartu_keluarga']): ?>
                        <div class="current-file">File saat ini: <a href="../public/uploads/<?php echo $data['kartu_keluarga']; ?>" target="_blank">Lihat</a></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>KTP Orang Tua</label>
                        <input type="file" name="ktp_ortu" accept=".jpg,.jpeg,.png,.pdf">
                        <?php if (isset($data['ktp_ortu']) && $data['ktp_ortu']): ?>
                        <div class="current-file">File saat ini: <a href="../public/uploads/<?php echo $data['ktp_ortu']; ?>" target="_blank">Lihat</a></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>Akta Kelahiran</label>
                        <input type="file" name="akta_kelahiran" accept=".jpg,.jpeg,.png,.pdf">
                        <?php if (isset($data['akta_kelahiran']) && $data['akta_kelahiran']): ?>
                        <div class="current-file">File saat ini: <a href="../public/uploads/<?php echo $data['akta_kelahiran']; ?>" target="_blank">Lihat</a></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>Ijazah/SKL</label>
                        <input type="file" name="ijazah" accept=".jpg,.jpeg,.png,.pdf">
                        <?php if (isset($data['ijazah']) && $data['ijazah']): ?>
                        <div class="current-file">File saat ini: <a href="../public/uploads/<?php echo $data['ijazah']; ?>" target="_blank">Lihat</a></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group full-width">
                        <label>Kartu KIP/KKS/PKH</label>
                        <input type="file" name="kartu_bantuan" accept=".jpg,.jpeg,.png,.pdf">
                        <?php if (isset($data['kartu_bantuan']) && $data['kartu_bantuan']): ?>
                        <div class="current-file">File saat ini: <a href="../public/uploads/<?php echo $data['kartu_bantuan']; ?>" target="_blank">Lihat</a></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group full-width">
                        <label>Surat Keterangan Sehat</label>
                        <input type="file" name="surat_sehat" accept=".jpg,.jpeg,.png,.pdf">
                        <?php if (isset($data['surat_sehat']) && $data['surat_sehat']): ?>
                        <div class="current-file">File saat ini: <a href="../public/uploads/<?php echo $data['surat_sehat']; ?>" target="_blank">Lihat</a></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div style="margin-top: 32px;">
                    <button type="submit" class="btn-submit">Simpan Perubahan</button>
                </div>
            </form>
        </main>
    </div>
</body>
</html>