<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password_lama = $_POST['password_lama'] ?? '';
    $password_baru = $_POST['password_baru'] ?? '';
    $konfirmasi_password = $_POST['konfirmasi_password'] ?? '';
    
    // Ambil ID admin
    $admin_id = $_SESSION['admin_id'] ?? null;
    $admin_name = $_SESSION['admin_name'] ?? '';

    if (!$admin_id) {
        // Fallback jika session ID belum ada (untuk user yang sudah login sebelum update script)
        $query_check = "SELECT * FROM admins WHERE nama_lengkap = '$admin_name'";
        $result_check = mysqli_query($koneksi, $query_check);
        if ($row_check = mysqli_fetch_assoc($result_check)) {
            $admin_id = $row_check['id'];
            $_SESSION['admin_id'] = $admin_id; // Simpan ke session
        }
    }

    if ($admin_id) {
        // Cek password lama
        $query = "SELECT * FROM admins WHERE id = '$admin_id' AND password = '$password_lama'";
        $result = mysqli_query($koneksi, $query);

        if (mysqli_num_rows($result) > 0) {
            // Password lama benar
            if ($password_baru === $konfirmasi_password) {
                if (!empty($password_baru)) {
                    // Update password
                    $query_update = "UPDATE admins SET password = '$password_baru' WHERE id = '$admin_id'";
                    if (mysqli_query($koneksi, $query_update)) {
                        $message = 'Password berhasil diubah!';
                        $message_type = 'success';
                    } else {
                        $message = 'Gagal mengubah password: ' . mysqli_error($koneksi);
                        $message_type = 'error';
                    }
                } else {
                    $message = 'Password baru tidak boleh kosong!';
                    $message_type = 'error';
                }
            } else {
                $message = 'Konfirmasi password tidak sesuai!';
                $message_type = 'error';
            }
        } else {
            $message = 'Password lama salah!';
            $message_type = 'error';
        }
    } else {
        $message = 'Data admin tidak ditemukan. Silakan login ulang.';
        $message_type = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganti Password - MA Darul Fithrah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../assets/css/ganti-password.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="sidebar-overlay" onclick="document.querySelector('.sidebar').classList.remove('active'); document.querySelector('.sidebar-overlay').classList.remove('active');"></div>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <a href="#" class="brand">
                <img src="../assets/img/logo.png" alt="Logo">
                <div class="brand-text">
                    <span class="brand-title">MA Darul Fithrah</span>
                    <span class="brand-subtitle">Madrasah Aliyah</span>
                </div>
            </a>
            
            <ul class="nav-menu">
                <li>
                    <a href="dashboard.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="data-pendaftar.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
                        Pendaftar Baru
                    </a>
                </li>
                <li>
                    <a href="status-penerimaan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                        Status Penerimaan
                    </a>
                </li>
                <li>
                    <a href="data-siswa.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        Data Siswa
                    </a>
                </li>
                <li>
                    <a href="laporan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        Laporan
                    </a>
                </li>
                <li>
                    <a href="arsip-data.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>
                        Arsip Data
                    </a>
                </li>
                <li>
                    <a href="ganti-password.php" class="nav-link active">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        Ganti Password
                    </a>
                </li>
                <li>
                    <a href="logout.php" class="nav-link logout-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Logout
                    </a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <button class="sidebar-toggle" onclick="document.querySelector('.sidebar').classList.add('active'); document.querySelector('.sidebar-overlay').classList.add('active');">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                </button>
                <div class="header-title">
                    <h1>Ganti Password</h1>
                    <p>Amankan akun Anda dengan mengganti password secara berkala</p>
                </div>
            </header>

            <div class="form-container">
                <?php if ($message): ?>
                    <div class="alert <?php echo ($message_type === 'success') ? 'alert-success' : 'alert-error'; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">
                    <div class="form-group">
                        <label>Password Lama</label>
                        <input type="password" name="password_lama" required placeholder="Masukkan password saat ini">
                    </div>
                    <div class="form-group">
                        <label>Password Baru</label>
                        <input type="password" name="password_baru" required placeholder="Masukkan password baru">
                    </div>
                    <div class="form-group">
                        <label>Konfirmasi Password Baru</label>
                        <input type="password" name="konfirmasi_password" required placeholder="Ulangi password baru">
                    </div>
                    <button type="submit" class="btn-submit">Simpan Password Baru</button>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
