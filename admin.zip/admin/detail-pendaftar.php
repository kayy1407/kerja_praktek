<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: data-pendaftar.php');
    exit;
}

$id = mysqli_real_escape_string($koneksi, $_GET['id']);
$query = "SELECT * FROM pendaftar WHERE id = '$id'";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    echo "<script>alert('Data tidak ditemukan!'); window.location.href='data-pendaftar.php';</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pendaftar - MA Darul Fithrah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../assets/css/custom-admin.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="sidebar-overlay" onclick="document.querySelector('.sidebar').classList.remove('active'); document.querySelector('.sidebar-overlay').classList.remove('active');"></div>
    <div class="admin-container">
        <aside class="sidebar">
            <a href="#" class="brand">
                <img src="../assets/img/logo.png" alt="Logo">
                <div class="brand-text">
                    <span class="brand-title">MA Darul Fithrah</span>
                    <span class="brand-subtitle">Madrasah Aliyah</span>
                </div>
            </a>
            <ul class="nav-menu">
                <li>
                    <a href="dashboard.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="data-pendaftar.php" class="nav-link active">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
                        Pendaftar Baru
                    </a>
                </li>
                <li>
                    <a href="status-penerimaan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                        Status Penerimaan
                    </a>
                </li>
                <li>
                    <a href="data-siswa.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        Data Siswa
                    </a>
                </li>
                <li>
                    <a href="laporan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        Laporan
                    </a>
                </li>
                <li>
                    <a href="arsip-data.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>
                        Arsip Data
                    </a>
                </li>
                <li>
                    <a href="ganti-password.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        Ganti Password
                    </a>
                </li>
                <li>
                    <a href="logout.php" class="nav-link logout-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Logout
                    </a>
                </li>
            </ul>
        </aside>

        <main class="main-content">
            <header class="header">
                <button class="sidebar-toggle" onclick="document.querySelector('.sidebar').classList.add('active'); document.querySelector('.sidebar-overlay').classList.add('active');">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                </button>
                <div class="header-title">
                    <h1>Detail Pendaftar</h1>
                    <p>Informasi lengkap pendaftar siswa baru</p>
                </div>
            </header>
            
            <a href="data-pendaftar.php" class="back-link">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                Kembali ke Data Pendaftar
            </a>

            <?php
            $status_class = 'status-menunggu';
            if ($data['status'] == 'Disetujui') $status_class = 'status-disetujui';
            if ($data['status'] == 'Ditolak') $status_class = 'status-ditolak';
            ?>
            <div class="detail-card <?php echo $status_class; ?>">
                <div class="detail-header">
                    <div class="detail-left">
                        <div class="detail-title">Data Diri Siswa</div>
                        <div class="user-chip">
                            <div class="avatar"><?php echo strtoupper(substr($data['nama'], 0, 1)); ?></div>
                            <div class="user-text">
                                <div class="user-name"><?php echo htmlspecialchars($data['nama']); ?></div>
                                <div class="user-sub"><?php echo htmlspecialchars($data['nisn'] ?? '-'); ?></div>
                            </div>
                        </div>
                    </div>
                    <span class="status-badge <?php echo $status_class; ?>"><?php echo $data['status']; ?></span>
                </div>
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-label">Nama Lengkap</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['nama']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">NISN</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['nisn'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Jenis Kelamin</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['jenis_kelamin']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Tempat, Tanggal Lahir</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['tempat_lahir']) . ', ' . date('d M Y', strtotime($data['tanggal_lahir'])); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Agama</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['agama']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Nomor HP</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['no_hp']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Email</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['email']); ?></div>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <div class="detail-label">Alamat Lengkap</div>
                        <div class="detail-value" style="line-height: 1.6;"><?php echo htmlspecialchars($data['alamat']); ?></div>
                    </div>
                </div>
            </div>

            <div class="detail-card">
                <div class="detail-header">
                    <div class="detail-title">Data Sekolah & Program</div>
                </div>
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-label">Kelas yang Dituju</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['kelas'] ?? '-'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Asal Sekolah</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['asal_sekolah']); ?></div>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <div class="detail-label">Sumber Informasi</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['sumber_info']); ?></div>
                    </div>
                </div>
            </div>

            <div class="detail-card">
                <div class="detail-header">
                    <div class="detail-title">Data Orang Tua</div>
                </div>
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-label">Nama Ayah</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['nama_ayah']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Pekerjaan Ayah</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['pekerjaan_ayah']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Nama Ibu</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['nama_ibu']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Pekerjaan Ibu</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['pekerjaan_ibu']); ?></div>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <div class="detail-label">No. HP Orang Tua</div>
                        <div class="detail-value"><?php echo htmlspecialchars($data['no_hp_ortu']); ?></div>
                    </div>
                </div>
            </div>

            <div class="detail-card">
                <div class="detail-header">
                    <div class="detail-title">Dokumen Pendukung</div>
                </div>
                <div class="document-section">
                    <div class="document-grid">
                        <?php if ($data['ijazah']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($data['ijazah']); ?>" class="document-preview" alt="Ijazah">
                            <div class="document-label">Ijazah/SKL</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($data['ijazah']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if ($data['akta_kelahiran']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($data['akta_kelahiran']); ?>" class="document-preview" alt="Akta">
                            <div class="document-label">Akta Kelahiran</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($data['akta_kelahiran']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($data['kartu_keluarga']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($data['kartu_keluarga']); ?>" class="document-preview" alt="KK">
                            <div class="document-label">Kartu Keluarga</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($data['kartu_keluarga']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if (isset($data['ktp_ortu']) && $data['ktp_ortu']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($data['ktp_ortu']); ?>" class="document-preview" alt="KTP Ortu">
                            <div class="document-label">KTP Orang Tua</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($data['ktp_ortu']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if ($data['kartu_bantuan']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($data['kartu_bantuan']); ?>" class="document-preview" alt="KIP/PKH">
                            <div class="document-label">KIP</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($data['kartu_bantuan']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if ($data['pas_foto']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($data['pas_foto']); ?>" class="document-preview" alt="Pas Foto">
                            <div class="document-label">Pas Foto</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($data['pas_foto']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if (isset($data['surat_sehat']) && $data['surat_sehat']): ?>
                        <div class="document-item">
                            <img src="../public/uploads/<?php echo htmlspecialchars($data['surat_sehat']); ?>" class="document-preview" alt="Surat Sehat">
                            <div class="document-label">Surat Keterangan Sehat</div>
                            <a href="../public/uploads/<?php echo htmlspecialchars($data['surat_sehat']); ?>" target="_blank" class="document-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                Lihat Full
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if ($data['status'] == 'Menunggu'): ?>
            <div class="action-buttons">
                <a href="proses.php?type=pendaftar&id=<?php echo $data['id']; ?>&action=setujui" class="btn btn-primary" style="width: auto; padding: 12px 24px;">Setujui Pendaftar</a>
                <a href="proses.php?type=pendaftar&id=<?php echo $data['id']; ?>&action=tolak" class="btn btn-danger" style="width: auto; padding: 12px 24px;">Tolak Pendaftar</a>
            </div>
            <?php elseif ($data['status'] == 'Disetujui' || $data['status'] == 'Ditolak'): ?>
            <div class="action-buttons">
                <a href="proses.php?type=pendaftar&id=<?php echo $data['id']; ?>&action=batalkan" class="btn btn-warning" style="width: auto; padding: 12px 24px;">Batalkan Status</a>
            </div>
            <?php endif; ?>

        </main>
    </div>
</body>
</html>
