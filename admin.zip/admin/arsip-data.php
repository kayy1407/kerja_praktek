<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

// Cek apakah tabel arsip sudah ada untuk menghindari error saat pertama kali load
$tabel_arsip_ada = false;
$result = mysqli_query($koneksi, "SHOW TABLES LIKE 'arsip_pendaftar'");
if (mysqli_num_rows($result) > 0) {
    $tabel_arsip_ada = true;
}

// Ambil daftar tahun ajaran yang sudah diarsipkan (satu entri per snapshot)
$list_arsip = [];
// Gunakan arsip_meta jika tersedia, fallback ke arsip_pendaftar (kompatibilitas lama)
$has_meta = mysqli_query($koneksi, "SHOW TABLES LIKE 'arsip_meta'");
if (mysqli_num_rows($has_meta) > 0) {
    $query = "SELECT tahun_ajaran, tgl_arsip FROM arsip_meta ORDER BY tgl_arsip DESC";
    $result = mysqli_query($koneksi, $query);
    while ($row = mysqli_fetch_assoc($result)) {
        $list_arsip[] = $row;
    }
} elseif ($tabel_arsip_ada) {
    $query = "SELECT DISTINCT tahun_ajaran, tgl_arsip FROM arsip_pendaftar ORDER BY tgl_arsip DESC";
    $result = mysqli_query($koneksi, $query);
    while ($row = mysqli_fetch_assoc($result)) {
        $list_arsip[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arsip Data - MA Darul Fithrah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../assets/css/arsip-data.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="sidebar-overlay" onclick="document.querySelector('.sidebar').classList.remove('active'); document.querySelector('.sidebar-overlay').classList.remove('active');"></div>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <a href="#" class="brand">
                <img src="../assets/img/logo.png" alt="Logo">
                <div class="brand-text">
                    <span class="brand-title">MA Darul Fithrah</span>
                    <span class="brand-subtitle">Madrasah Aliyah</span>
                </div>
            </a>
            <ul class="nav-menu">
                <li>
                    <a href="dashboard.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="data-pendaftar.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
                        Pendaftar Baru
                    </a>
                </li>
                <li>
                    <a href="status-penerimaan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                        Status Penerimaan
                    </a>
                </li>
                <li>
                    <a href="data-siswa.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        Data Siswa
                    </a>
                </li>
                <li>
                    <a href="laporan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        Laporan
                    </a>
                </li>
                <li>
                    <a href="arsip-data.php" class="nav-link active">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>
                        Arsip Data
                    </a>
                </li>
                <li>
                    <a href="ganti-password.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        Ganti Password
                    </a>
                </li>
                <li>
                    <a href="logout.php" class="nav-link logout-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Logout
                    </a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <button class="sidebar-toggle" onclick="document.querySelector('.sidebar').classList.add('active'); document.querySelector('.sidebar-overlay').classList.add('active');">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                </button>
                <div class="header-title">
                    <h1>Arsip Data</h1>
                    <p>Kelola arsip data tahunan dan reset sistem</p>
                </div>
            </header>

            <?php if (isset($_GET['status'])): ?>
                <?php if ($_GET['status'] == 'success'): ?>
                    <div class="alert alert-success" style="background-color: #d1fae5; color: #065f46; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                        Data berhasil diarsipkan dan sistem telah direset untuk tahun ajaran baru.
                    </div> 
                <?php elseif ($_GET['status'] == 'success_delete'): ?>
                    <div class="alert alert-success" style="background-color: #d1fae5; color: #065f46; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                        Arsip data berhasil dihapus secara permanen.
                    </div> 
                <?php elseif ($_GET['status'] == 'error'): ?>
                    <div class="alert alert-error" style="background-color: #fee2e2; color: #991b1b; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                        Terjadi kesalahan: <?php echo htmlspecialchars($_GET['message'] ?? 'Gagal memproses arsip.'); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="archive-card">
                <div class="archive-header">
                    <div class="archive-title">
                        <h2>Arsipkan Data Tahun Ini</h2>
                        <p>Simpan semua data pendaftar dan siswa, lalu kosongkan sistem untuk tahun ajaran baru.</p>
                    </div>
                    <button onclick="openModal()" class="btn-archive">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
                        Simpan & Reset Data
                    </button>
                </div>
            </div>

            <?php if (empty($list_arsip)): ?>
                <div class="empty-state">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="empty-icon"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>
                    <p>Belum ada data arsip tersimpan.</p>
                </div>
            <?php else: ?>
                <div class="archive-list">
                    <?php foreach ($list_arsip as $arsip): ?>
                        <div class="archive-item">
                            <div class="archive-year">Tahun Ajaran <?php echo htmlspecialchars($arsip['tahun_ajaran']); ?></div>
                            <div class="archive-date">Diarsipkan pada: <?php echo date('d M Y H:i', strtotime($arsip['tgl_arsip'])); ?></div>
                            <div class="archive-stats">
                                <div class="stat-item">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                                    Data Tersimpan
                                </div>
                            </div>
                            <div class="archive-actions">
                                <a href="detail-arsip.php?tahun=<?php echo urlencode($arsip['tahun_ajaran']); ?>" class="btn-view">Lihat Data</a>
                                <button onclick="openDeleteModal('<?php echo htmlspecialchars($arsip['tahun_ajaran']); ?>')" class="btn-delete-archive" title="Hapus Permanen">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <!-- Modal Konfirmasi Arsip -->
    <div id="archiveModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Simpan & Reset Data</h3>
                <p class="modal-desc">
                    Tindakan ini akan <b>memindahkan semua data saat ini ke arsip</b> dan <b>mengosongkan semua data</b> (Dashboard, Pendaftar, Siswa) untuk memulai tahun ajaran baru. Tindakan ini tidak dapat dibatalkan.
                </p>
            </div>
            <form action="proses.php?type=arsip" method="POST">
                <div class="form-group">
                    <label for="tahun_ajaran">Label Tahun Ajaran (Untuk Arsip)</label>
                    <input type="text" name="tahun_ajaran" id="tahun_ajaran" class="form-input" placeholder="Contoh: 2024/2025" required>
                </div>
                <div class="form-group">
                    <label for="konfirmasi">Ketik "SETUJU" untuk konfirmasi</label>
                    <input type="text" name="konfirmasi" id="konfirmasi" class="form-input" placeholder="Ketik SETUJU disini" required>
                </div>
                <div class="modal-actions">
                    <button type="button" onclick="closeModal()" class="btn-cancel">Batal</button>
                    <button type="submit" class="btn-confirm">Simpan & Reset</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Konfirmasi Hapus Arsip -->
    <div id="deleteArchiveModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" style="color: #ef4444;">Hapus Arsip Permanen</h3>
                <p class="modal-desc">
                    Apakah Anda yakin ingin menghapus arsip data tahun ajaran <b id="deleteYear"></b>? 
                    Data yang dihapus <b>TIDAK DAPAT DIKEMBALIKAN</b>.
                </p>
            </div>
            <form action="proses.php?type=arsip&action=delete" method="POST">
                <input type="hidden" name="tahun_ajaran" id="deleteYearInput">
                <div class="form-group">
                    <label for="konfirmasi_hapus">Ketik "HAPUS" untuk konfirmasi</label>
                    <input type="text" name="konfirmasi_hapus" id="konfirmasi_hapus" class="form-input" placeholder="Ketik HAPUS disini" required>
                </div>
                <div class="modal-actions">
                    <button type="button" onclick="closeDeleteModal()" class="btn-cancel">Batal</button>
                    <button type="submit" class="btn-confirm" style="background-color: #ef4444;">Hapus Permanen</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Modal Arsip
        function openModal() {
            document.getElementById('archiveModal').classList.add('active');
        }

        function closeModal() {
            document.getElementById('archiveModal').classList.remove('active');
        }

        // Modal Hapus Arsip
        function openDeleteModal(tahun) {
            document.getElementById('deleteYear').textContent = tahun;
            document.getElementById('deleteYearInput').value = tahun;
            document.getElementById('deleteArchiveModal').classList.add('active');
        }

        function closeDeleteModal() {
            document.getElementById('deleteArchiveModal').classList.remove('active');
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            var archiveModal = document.getElementById('archiveModal');
            var deleteModal = document.getElementById('deleteArchiveModal');
            
            if (event.target == archiveModal) {
                closeModal();
            }
            if (event.target == deleteModal) {
                closeDeleteModal();
            }
        }
    </script>
</body>
</html>
