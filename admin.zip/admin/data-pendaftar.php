<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

// Ambil data pendaftar dengan fitur pencarian
$where_clause = "";
$search_keyword = "";

if (isset($_GET['q'])) {
    $search_keyword = mysqli_real_escape_string($koneksi, $_GET['q']);
    $where_clause = "WHERE nama LIKE '%$search_keyword%' OR asal_sekolah LIKE '%$search_keyword%' OR email LIKE '%$search_keyword%'";
}

$query = "SELECT * FROM pendaftar $where_clause ORDER BY created_at DESC";
$result = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftar Baru - MA Darul Fithrah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css?v=<?php echo time(); ?>">
</head>
<body>
    <div class="sidebar-overlay" onclick="document.querySelector('.sidebar').classList.remove('active'); document.querySelector('.sidebar-overlay').classList.remove('active');"></div>
    <div class="admin-container">
        <aside class="sidebar">
            <a href="#" class="brand">
                <img src="../assets/img/logo.png" alt="Logo">
                <div class="brand-text">
                    <span class="brand-title">MA Darul Fithrah</span>
                    <span class="brand-subtitle">Madrasah Aliyah</span>
                </div>
            </a>
            <ul class="nav-menu">
                <li>
                    <a href="dashboard.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="data-pendaftar.php" class="nav-link active">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
                        Pendaftar Baru
                    </a>
                </li>
                <li>
                    <a href="status-penerimaan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                        Status Penerimaan
                    </a>
                </li>
                <li>
                    <a href="data-siswa.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        Data Siswa
                    </a>
                </li>
                <li>
                    <a href="laporan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        Laporan
                    </a>
                </li>
                <li>
                    <a href="arsip-data.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>
                        Arsip Data
                    </a>
                </li>
                <li>
                    <a href="ganti-password.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        Ganti Password
                    </a>
                </li>
                <li>
                    <a href="logout.php" class="nav-link logout-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Logout 
                    </a>
                </li>
            </ul>
        </aside>

        <main class="main-content">
            <header class="header">
                <div style="display: flex; align-items: center;">
                    <button class="sidebar-toggle" onclick="document.querySelector('.sidebar').classList.add('active'); document.querySelector('.sidebar-overlay').classList.add('active');">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                    </button>
                    <div class="header-title">
                        <h1>Pendaftar Baru</h1>
                        <p>Daftar pendaftar terbaru dengan detail lengkap</p>
                    </div>
                </div>
            </header>

            <div class="filters">
                <div class="filter-left">
                    <form action="" method="GET" class="search" onsubmit="return false;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        <input type="text" id="searchInput" name="q" placeholder="Ketik untuk mencari otomatis..." value="<?php echo htmlspecialchars($search_keyword); ?>" autocomplete="off">
                    </form>
                </div>
                <div class="filter-right">
                    <select class="select" id="kelasFilter">
                        <option value="Semua">Semua</option>
                        <option value="X">Kelas X</option>
                        <option value="XI">Kelas XI</option>
                        <option value="XII">Kelas XII</option>
                    </select>
                    <select class="select" id="statusFilter">
                        <option value="Semua">Semua</option>
                        <option value="Menunggu">Menunggu</option>
                        <option value="Disetujui">Disetujui</option>
                        <option value="Ditolak">Ditolak</option>
                    </select>
                    <select class="select" id="sortFilter">
                        <option value="Terbaru">Terbaru</option>
                        <option value="Nama A-Z">Nama A-Z</option>
                        <option value="Nama Z-A">Nama Z-A</option>
                    </select>
                </div>
            </div>

            <div class="table-card">
                        <div class="table-scroll">
                            <table class="table">
                                <colgroup>
                                    <col class="col-name">  
                                    <col class="col-regno">
                                    <col class="col-date">
                                    <col class="col-status">
                                    <col class="col-actions">
                                </colgroup>
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Nomor Pendaftaran</th>
                                        <th>Tanggal Daftar</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="pendaftarTableBody">
                                    <?php if (mysqli_num_rows($result) > 0): ?>
                                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                        <tr>
                                            <td>
                                                <div class="user-info">
                                                    <div class="name"><?php echo htmlspecialchars($row['nama']); ?></div>
                                                    <div class="sub-text" style="font-size: 12px; color: #666;"><?php echo htmlspecialchars($row['kelas'] ?? '-'); ?></div>
                                                </div>
                                            </td>
                                            <?php
                                                $year = (int)date('Y', strtotime($row['created_at']));
                                                $cntRes = mysqli_query($koneksi, "SELECT COUNT(*) AS pos FROM pendaftar WHERE YEAR(created_at) = $year AND id <= " . (int)$row['id']);
                                                $cntRow = $cntRes ? mysqli_fetch_assoc($cntRes) : ['pos' => 1];
                                                $pos = (int)$cntRow['pos'];
                                                if ($pos < 1) { $pos = 1; }
                                                $no_fmt = 'DF-' . $year . '-' . str_pad($pos, 4, '0', STR_PAD_LEFT);
                                            ?>
                                            <td><?php echo htmlspecialchars($no_fmt); ?></td>
                                            <td><?php echo date('d M Y', strtotime($row['tanggal_daftar'])); ?></td>
                                            <td>
                                                <?php
                                                $badge_class = 'badge-warning';
                                                if ($row['status'] == 'Disetujui') $badge_class = 'badge-success';
                                                if ($row['status'] == 'Ditolak') $badge_class = 'badge-danger';
                                                ?>
                                                <span class="badge <?php echo $badge_class; ?>"><?php echo $row['status']; ?></span>
                                            </td>
                                            <td class="actions" style="white-space: nowrap;">
                                                <a href="detail-pendaftar.php?id=<?php echo $row['id']; ?>" class="btn btn-outline" title="Detail" style="padding: 0; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                                </a>
                                        <?php if ($row['status'] == 'Menunggu'): ?>
                                            <a href="proses.php?type=pendaftar&id=<?php echo $row['id']; ?>&action=setujui" class="btn btn-primary" title="Setujui" style="padding: 0; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                            </a>
                                            <a href="proses.php?type=pendaftar&id=<?php echo $row['id']; ?>&action=tolak" class="btn btn-danger" title="Tolak" style="padding: 0; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                            </a>
                                        <?php elseif ($row['status'] == 'Disetujui' || $row['status'] == 'Ditolak'): ?>
                                            <a href="proses.php?type=pendaftar&id=<?php echo $row['id']; ?>&action=batalkan" class="btn btn-warning" title="Batalkan" style="padding: 0; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>
                                            </a>
                                        <?php endif; ?>
                                        <?php if ($row['status'] != 'Disetujui'): ?>
                                            <a href="proses.php?type=pendaftar&id=<?php echo $row['id']; ?>&action=hapus" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini? Data yang dihapus tidak dapat dikembalikan.')" title="Hapus" style="padding: 0; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" style="text-align:center; padding: 40px 20px; color: #64748b;">
                                                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="opacity: 0.5;"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                                                    <span style="font-size: 14px;">Belum ada pendaftar baru</span>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var searchInput = document.getElementById('searchInput');
        var statusFilter = document.getElementById('statusFilter');
        var kelasFilter = document.getElementById('kelasFilter');
        var sortFilter = document.getElementById('sortFilter');
        var tableBody = document.getElementById('pendaftarTableBody');

        function fetchPendaftar() {
            var keyword = searchInput ? searchInput.value : '';
            var status = statusFilter ? statusFilter.value : 'Semua';
            var kelas = kelasFilter ? kelasFilter.value : 'Semua';
            var sort = sortFilter ? sortFilter.value : 'Terbaru';

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    tableBody.innerHTML = this.responseText;
                }
            };
            
            var url = "ajax.php?type=pendaftar&q=" + encodeURIComponent(keyword) + 
                      "&s=" + encodeURIComponent(status) + 
                      "&k=" + encodeURIComponent(kelas) +
                      "&o=" + encodeURIComponent(sort) +
                      "&t=" + new Date().getTime();
            
            xhr.open("GET", url, true);
            xhr.send();
        }

        if (searchInput && tableBody) {
            searchInput.addEventListener('keyup', fetchPendaftar);
            searchInput.addEventListener('input', fetchPendaftar);
        }

        if (statusFilter) {
            statusFilter.addEventListener('change', fetchPendaftar);
        }

        if (kelasFilter) {
            kelasFilter.addEventListener('change', fetchPendaftar);
        }

        if (sortFilter) {
            sortFilter.addEventListener('change', fetchPendaftar);
        }
    });
    </script>
</body>
</html>
