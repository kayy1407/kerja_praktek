<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

// --- LOGIKA FILTER ---
$where_clauses = [];
$label_filter = "";

// Filter Keyword (Nama atau Asal Sekolah)
if (isset($_GET['q']) && !empty($_GET['q'])) {
    $search_keyword = mysqli_real_escape_string($koneksi, $_GET['q']);
    $where_clauses[] = "(nama LIKE '%$search_keyword%' OR asal_sekolah LIKE '%$search_keyword%')";
    $label_filter .= "Pencarian: '$search_keyword' ";
}

// Filter Status
if (isset($_GET['s']) && !empty($_GET['s']) && $_GET['s'] != 'Semua') {
    $status_filter = mysqli_real_escape_string($koneksi, $_GET['s']);
    $where_clauses[] = "status = '$status_filter'";
    $label_filter .= ($label_filter ? "| " : "") . "Status: $status_filter";
}

$where_sql = "";
if (count($where_clauses) > 0) {
    $where_sql = "WHERE " . implode(" AND ", $where_clauses);
} else {
    $label_filter = "Semua Data";
}

$query = "SELECT * FROM pendaftar $where_sql ORDER BY created_at DESC";
$result = mysqli_query($koneksi, $query);

// Fungsi sederhana untuk ubah nama bulan ke Indonesia
function bulan_indo($str) {
    $bulan_inggris = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $bulan_indo = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return str_ireplace($bulan_inggris, $bulan_indo, $str);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Status Penerimaan - MA Darul Fithrah</title>
    <link rel="stylesheet" href="../assets/css/laporan-print.css">
    <style>
        .badge {
            display: inline-block;
            padding: 4px 8px;
            font-size: 10pt;
            font-weight: bold;
            border-radius: 4px;
            text-transform: uppercase;
        }
        /* Mode cetak biasanya hitam putih, tapi kita bisa beri border/style minimal */
        .badge-success { border: 1px solid #000; }
        .badge-warning { border: 1px dashed #000; }
        .badge-danger { text-decoration: line-through; }
    </style>
</head>
<body onload="window.print()">

    <!-- Tombol Kembali (Hanya tampil di layar) -->
    <div class="no-print" style="margin-bottom: 20px;">
        <button onclick="window.close()" style="padding: 10px 20px; cursor: pointer;">Tutup / Kembali</button>
    </div>

    <div class="kop-surat">
        <!-- Pastikan path logo benar relative terhadap file ini -->
        <img src="../assets/img/logo.png" alt="Logo" class="kop-logo">
        <div class="kop-text">
            <h1>MA DARUL FITHRAH</h1>
            <h2>MADRASAH ALIYAH</h2>
            <p>Alamat: Kampung Parigi, Desa Ciparay, Kecamatan Ciparay, Kabupaten Bandung, Provinsi Jawa Barat</p>
            <p>Email: ponpestahfidzdarulfithrah@gmail.com | Telp: 0821-2127-2601</p>
        </div>
    </div>

    <div class="laporan-title">
        <h3>LAPORAN STATUS PENERIMAAN SISWA BARU</h3>
        <p>Periode Cetak: <?php echo bulan_indo(date('d F Y')); ?></p>
        <p style="font-size: 10pt; font-style: italic; margin-top: 5px;">(<?php echo htmlspecialchars($label_filter); ?>)</p>
    </div>

    <table>
        <thead>
            <tr>
                <th style="width: 40px;">No</th>
                <th>Nama Calon Siswa</th>
                <th>Asal Sekolah</th>
                <th>Tanggal Daftar</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if (mysqli_num_rows($result) > 0): 
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)): 
            ?>
                <tr>
                    <td class="text-center"><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($row['nama']); ?></td>
                    <td><?php echo htmlspecialchars($row['asal_sekolah']); ?></td>
                    <td class="text-center"><?php echo date('d/m/Y', strtotime($row['tanggal_daftar'])); ?></td>
                    <td class="text-center">
                        <?php echo $row['status']; ?>
                    </td>
                </tr>
            <?php 
                endwhile; 
            else: 
            ?>
                <tr>
                    <td colspan="5" class="text-center">Tidak ada data ditemukan.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="ttd-area">
        <p>Jakarta, <?php echo bulan_indo(date('d F Y')); ?></p>
        <p>Kepala Madrasah,</p>
        <div class="ttd-space"></div>
        <p><strong>Dra. Euis Nurhayati., S.Pd.</strong></p>
        <p>NIP. ...........................</p>
    </div>

</body>
</html>
