<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

$type = $_GET['type'] ?? '';

// Handle POST request (Arsip)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $type === 'arsip') {
    $action = $_GET['action'] ?? 'create';

    if ($action === 'delete') {
        $tahun_ajaran = mysqli_real_escape_string($koneksi, $_POST['tahun_ajaran']);
        $konfirmasi = $_POST['konfirmasi_hapus'];

        if ($konfirmasi !== 'HAPUS') {
            header("Location: arsip-data.php?status=error&message=Konfirmasi salah. Harap ketik HAPUS.");
            exit;
        }

        mysqli_begin_transaction($koneksi);
        try {
            mysqli_query($koneksi, "DELETE FROM arsip_pendaftar WHERE tahun_ajaran = '$tahun_ajaran'");
            mysqli_query($koneksi, "DELETE FROM arsip_siswa WHERE tahun_ajaran = '$tahun_ajaran'");
            mysqli_query($koneksi, "DELETE FROM arsip_meta WHERE tahun_ajaran = '$tahun_ajaran'");
            
            mysqli_commit($koneksi);
            header("Location: arsip-data.php?status=success_delete");
            exit;
        } catch (Exception $e) {
            mysqli_rollback($koneksi);
            header("Location: arsip-data.php?status=error&message=" . urlencode($e->getMessage()));
            exit;
        }
    }

    // Default action: create (Simpan & Reset)
    $tahun_ajaran = mysqli_real_escape_string($koneksi, $_POST['tahun_ajaran']);
    $konfirmasi = $_POST['konfirmasi'];

    if ($konfirmasi !== 'SETUJU') {
        header("Location: arsip-data.php?status=error&message=Konfirmasi tidak sesuai. Harap ketik SETUJU.");
        exit;
    }

    if (empty($tahun_ajaran)) {
        header("Location: arsip-data.php?status=error&message=Tahun ajaran tidak boleh kosong.");
        exit;
    }

    mysqli_begin_transaction($koneksi);

    try {
        // Setup Tabel Arsip Meta (satu entri per snapshot)
        $check_meta = mysqli_query($koneksi, "SHOW TABLES LIKE 'arsip_meta'");
        if (mysqli_num_rows($check_meta) == 0) {
            mysqli_query($koneksi, "CREATE TABLE arsip_meta (id INT AUTO_INCREMENT PRIMARY KEY, tahun_ajaran VARCHAR(20) NOT NULL, tgl_arsip DATETIME NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        }
        $snapshot = date('Y-m-d H:i:s');
        $snapshot_date = date('Y-m-d');
        mysqli_query($koneksi, "INSERT INTO arsip_meta (tahun_ajaran, tgl_arsip) VALUES ('$tahun_ajaran', '$snapshot')");

        // Setup Tabel Arsip Pendaftar
        $check_table = mysqli_query($koneksi, "SHOW TABLES LIKE 'arsip_pendaftar'");
        if (mysqli_num_rows($check_table) == 0) {
            mysqli_query($koneksi, "CREATE TABLE arsip_pendaftar SELECT * FROM pendaftar WHERE 1=0");
            mysqli_query($koneksi, "ALTER TABLE arsip_pendaftar ADD COLUMN tahun_ajaran VARCHAR(20), ADD COLUMN tgl_arsip DATETIME");
        }

        // Setup Tabel Arsip Siswa
        $check_table_siswa = mysqli_query($koneksi, "SHOW TABLES LIKE 'arsip_siswa'");
        if (mysqli_num_rows($check_table_siswa) == 0) {
            mysqli_query($koneksi, "CREATE TABLE arsip_siswa SELECT * FROM siswa WHERE 1=0");
            mysqli_query($koneksi, "ALTER TABLE arsip_siswa ADD COLUMN tahun_ajaran VARCHAR(20), ADD COLUMN tgl_arsip DATETIME");
        }

        // Pindahkan Data (eksplisit kolom, tanpa menyalin id untuk menghindari konflik)
        $sql_arsip_pendaftar = "
            INSERT INTO arsip_pendaftar (
                nama, nisn, jenis_kelamin, tempat_lahir, tanggal_lahir, agama, no_hp, email, alamat, asal_sekolah,
                nama_ayah, pekerjaan_ayah, nama_ibu, pekerjaan_ibu, no_hp_ortu, kelas, sumber_info,
                pas_foto, kartu_keluarga, akta_kelahiran, ijazah, kartu_bantuan, ktp_ortu, surat_sehat,
                status, tanggal_daftar, created_at, tahun_ajaran, tgl_arsip
            )
            SELECT
                nama, nisn, jenis_kelamin, tempat_lahir, tanggal_lahir, agama, no_hp, email, alamat, asal_sekolah,
                nama_ayah, pekerjaan_ayah, nama_ibu, pekerjaan_ibu, no_hp_ortu, kelas, sumber_info,
                pas_foto, kartu_keluarga, akta_kelahiran, ijazah, kartu_bantuan, ktp_ortu, surat_sehat,
                status, tanggal_daftar, created_at, '$tahun_ajaran', '$snapshot_date'
            FROM pendaftar
        ";
        if (!mysqli_query($koneksi, $sql_arsip_pendaftar)) {
            throw new Exception("Gagal mengarsipkan data pendaftar: " . mysqli_error($koneksi));
        }
        $sql_arsip_siswa = "
            INSERT INTO arsip_siswa (
                nis, nisn, nama, status, alamat, created_at, tahun_ajaran, tgl_arsip, kelas
            )
            SELECT
                nis, nisn, nama, status, alamat, created_at, '$tahun_ajaran', '$snapshot_date', kelas
            FROM siswa
        ";
        if (!mysqli_query($koneksi, $sql_arsip_siswa)) {
            throw new Exception("Gagal mengarsipkan data siswa: " . mysqli_error($koneksi));
        }

        // Reset Tabel
        mysqli_query($koneksi, "SET FOREIGN_KEY_CHECKS = 0");
        if (!mysqli_query($koneksi, "TRUNCATE TABLE pendaftar")) {
            throw new Exception("Gagal mereset tabel pendaftar: " . mysqli_error($koneksi));
        }
        if (!mysqli_query($koneksi, "TRUNCATE TABLE siswa")) {
            throw new Exception("Gagal mereset tabel siswa: " . mysqli_error($koneksi));
        }
        mysqli_query($koneksi, "SET FOREIGN_KEY_CHECKS = 1");

        mysqli_commit($koneksi);
        header("Location: arsip-data.php?status=success");
        exit;

    } catch (Exception $e) {
        mysqli_rollback($koneksi);
        header("Location: arsip-data.php?status=error&message=" . urlencode($e->getMessage()));
        exit;
    }
}

// Handle GET requests (Actions)
if (isset($_GET['id']) && isset($_GET['action'])) {
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);
    $action = $_GET['action'];

    // Action Pendaftar
    if ($type === 'pendaftar') {
        if ($action == 'setujui') {
            $query_update = "UPDATE pendaftar SET status = 'Disetujui' WHERE id = '$id'";
            if (mysqli_query($koneksi, $query_update)) {
                $query_pendaftar = "SELECT * FROM pendaftar WHERE id = '$id'";
                $result_pendaftar = mysqli_query($koneksi, $query_pendaftar);
                
                if ($row = mysqli_fetch_assoc($result_pendaftar)) {
                    $nama = mysqli_real_escape_string($koneksi, $row['nama']);
                    $nisn = mysqli_real_escape_string($koneksi, $row['nisn']);
                    $alamat = mysqli_real_escape_string($koneksi, $row['alamat']);
                    $nis = date('Y') . sprintf("%04d", $id);
                    $kelas = mysqli_real_escape_string($koneksi, $row['kelas']);

                    $check_siswa = mysqli_query($koneksi, "SELECT id FROM siswa WHERE nama = '$nama' AND alamat = '$alamat'");
                    if (mysqli_num_rows($check_siswa) == 0) {
                        $query_insert = "INSERT INTO siswa (nis, nisn, nama, kelas, status, alamat) VALUES ('$nis', '$nisn', '$nama', '$kelas', 'Aktif', '$alamat')";
                        mysqli_query($koneksi, $query_insert);
                    }
                }
                header('Location: data-pendaftar.php');
            } else {
                echo "<script>alert('Gagal menyetujui pendaftar: " . mysqli_error($koneksi) . "'); window.location.href='data-pendaftar.php';</script>";
            }
        } elseif ($action == 'tolak') {
            if (mysqli_query($koneksi, "UPDATE pendaftar SET status = 'Ditolak' WHERE id = '$id'")) {
                header('Location: data-pendaftar.php');
            } else {
                echo "<script>alert('Gagal menolak pendaftar: " . mysqli_error($koneksi) . "'); window.location.href='data-pendaftar.php';</script>";
            }
        } elseif ($action == 'batalkan') {
            $q_check = mysqli_query($koneksi, "SELECT nama, alamat FROM pendaftar WHERE id = '$id'");
            $data_p = mysqli_fetch_assoc($q_check);

            if (mysqli_query($koneksi, "UPDATE pendaftar SET status = 'Menunggu' WHERE id = '$id'")) {
                if ($data_p) {
                    $nama = mysqli_real_escape_string($koneksi, $data_p['nama']);
                    $alamat = mysqli_real_escape_string($koneksi, $data_p['alamat']);
                    mysqli_query($koneksi, "DELETE FROM siswa WHERE nama = '$nama' AND alamat = '$alamat'");
                }
                header('Location: data-pendaftar.php');
            } else {
                echo "<script>alert('Gagal membatalkan status: " . mysqli_error($koneksi) . "'); window.location.href='data-pendaftar.php';</script>";
            }
        } elseif ($action == 'hapus') {
            $q_check = mysqli_query($koneksi, "SELECT nama, alamat FROM pendaftar WHERE id = '$id'");
            $data_p = mysqli_fetch_assoc($q_check);

            if (mysqli_query($koneksi, "DELETE FROM pendaftar WHERE id = '$id'")) {
                if ($data_p) {
                    $nama = mysqli_real_escape_string($koneksi, $data_p['nama']);
                    $alamat = mysqli_real_escape_string($koneksi, $data_p['alamat']);
                    mysqli_query($koneksi, "DELETE FROM siswa WHERE nama = '$nama' AND alamat = '$alamat'");
                    
                    if (mysqli_affected_rows($koneksi) == 0) {
                        mysqli_query($koneksi, "DELETE FROM siswa WHERE nama = '$nama' AND (alamat IS NULL OR alamat = '')");
                    }
                }

                $cek_kosong = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pendaftar");
                $row_kosong = mysqli_fetch_assoc($cek_kosong);
                if ($row_kosong['total'] == 0) {
                    mysqli_query($koneksi, "TRUNCATE TABLE siswa");
                }
                
                header('Location: data-pendaftar.php');
            } else {
                echo "<script>alert('Gagal menghapus data: " . mysqli_error($koneksi) . "'); window.location.href='data-pendaftar.php';</script>";
            }
        }
    } 
    // Action Siswa
    elseif ($type === 'siswa') {
        if ($action == 'nonaktifkan') {
            if (mysqli_query($koneksi, "UPDATE siswa SET status = 'Nonaktif' WHERE id = '$id'")) {
                header('Location: data-siswa.php');
            } else {
                echo "<script>alert('Gagal menonaktifkan siswa: " . mysqli_error($koneksi) . "'); window.location.href='data-siswa.php';</script>";
            }
        } elseif ($action == 'aktifkan') {
            if (mysqli_query($koneksi, "UPDATE siswa SET status = 'Aktif' WHERE id = '$id'")) {
                header('Location: data-siswa.php');
            } else {
                echo "<script>alert('Gagal mengaktifkan siswa: " . mysqli_error($koneksi) . "'); window.location.href='data-siswa.php';</script>";
            }
        } elseif ($action == 'hapus') {
            $query_get = "SELECT * FROM siswa WHERE id = '$id'";
            $result_get = mysqli_query($koneksi, $query_get);
            $data_siswa = mysqli_fetch_assoc($result_get);

            if ($data_siswa) {
                $nama = mysqli_real_escape_string($koneksi, $data_siswa['nama']);
                $alamat = mysqli_real_escape_string($koneksi, $data_siswa['alamat']);

                if (mysqli_query($koneksi, "DELETE FROM siswa WHERE id = '$id'")) {
                    if (!empty($alamat)) {
                        mysqli_query($koneksi, "DELETE FROM pendaftar WHERE nama = '$nama' AND alamat = '$alamat'");
                    } else {
                        mysqli_query($koneksi, "DELETE FROM pendaftar WHERE nama = '$nama'");
                    }

                    $cek_kosong = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pendaftar");
                    $row_kosong = mysqli_fetch_assoc($cek_kosong);
                    if ($row_kosong['total'] == 0) {
                         mysqli_query($koneksi, "TRUNCATE TABLE siswa");
                    }

                    header('Location: data-siswa.php');
                } else {
                    echo "<script>alert('Gagal menghapus siswa: " . mysqli_error($koneksi) . "'); window.location.href='data-siswa.php';</script>";
                }
            } else {
                header('Location: data-siswa.php');
            }
        }
    } else {
        header('Location: dashboard.php');
    }
} else {
    header('Location: dashboard.php');
}
?>
