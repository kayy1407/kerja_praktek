<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

// --- LOGIKA FILTER ---
$periode = isset($_GET['periode']) ? $_GET['periode'] : '12'; // Default 12 bulan
$kelas_filter = isset($_GET['kelas']) ? $_GET['kelas'] : 'Semua'; // Default Semua

// 1. Hitung Total Siswa Aktif
$query_siswa_aktif = "SELECT COUNT(*) as total FROM siswa WHERE status = 'Aktif'";
// Jika ada filter kelas untuk statistik utama (opsional, tapi biasanya statistik utama global)
// Kita biarkan global dulu agar sesuai dashboard

$result_siswa_aktif = mysqli_query($koneksi, $query_siswa_aktif);
$row_siswa_aktif = mysqli_fetch_assoc($result_siswa_aktif);
$total_siswa_aktif = $row_siswa_aktif['total'];

// 2. Hitung Total Pendaftar
$query_total_pendaftar = "SELECT COUNT(*) as total FROM pendaftar";
$result_total_pendaftar = mysqli_query($koneksi, $query_total_pendaftar);
$row_total_pendaftar = mysqli_fetch_assoc($result_total_pendaftar);
$total_pendaftar = $row_total_pendaftar['total'];


// 3. Data Tren Pendaftar (DIHAPUS)
// $query_tren = ...;
// $result_tren = ...;


// 4. Data Distribusi Siswa
$where_kelas = "WHERE status = 'Aktif'";

// Query untuk mengambil data yang ada di database
$query_distribusi = "SELECT kelas, COUNT(*) as total
FROM siswa
$where_kelas
GROUP BY kelas
ORDER BY kelas ASC";

$result_distribusi = mysqli_query($koneksi, $query_distribusi);

// Normalisasi data agar semua kelas (X, XI, XII) tetap muncul meski jumlahnya 0
$raw_data = [];
while ($row = mysqli_fetch_assoc($result_distribusi)) {
    $raw_data[$row['kelas']] = $row['total'];
}

// Definisi kelas standar
$standard_classes = ['X (Sepuluh)', 'XI (Sebelas)', 'XII (Dua Belas)'];

// Gabungkan kelas standar dengan kelas yang ada di database (agar kelas non-standar juga muncul)
$all_classes = array_unique(array_merge($standard_classes, array_keys($raw_data)));
sort($all_classes); // Urutkan abjad

$final_distribusi = [];
$total_terfilter = 0;

foreach ($all_classes as $cls) {
    // Logika Filter:
    // Jika filter 'Semua', masukkan semua kelas.
    // Jika filter spesifik (misal 'X'), hanya masukkan yang mengandung string tersebut.
    
    $show_class = false;
    if ($kelas_filter == 'Semua') {
        $show_class = true;
    } elseif ($kelas_filter == 'X' && strpos($cls, 'X') === 0 && strpos($cls, 'XI') !== 0) { 
         // Match "X..." but not "XI..." or "XII..."
         // Perbaikan logika: strpos($cls, 'X') === 0 ensures it starts with X.
         // But "XI" also starts with X. So we must exclude "XI" and "XII".
         $show_class = true;
    } elseif ($kelas_filter == 'XI' && strpos($cls, 'XI') === 0 && strpos($cls, 'XII') !== 0) {
         // Match "XI..." but not "XII..."
         $show_class = true;
    } elseif ($kelas_filter == 'XII' && strpos($cls, 'XII') === 0) {
         $show_class = true;
    }

    if ($show_class) {
        $count = isset($raw_data[$cls]) ? $raw_data[$cls] : 0;
        $final_distribusi[] = [
            'kelas' => $cls,
            'total' => $count
        ];
        $total_terfilter += $count;
    }
}


// Fungsi sederhana untuk ubah nama bulan ke Indonesia
function bulan_indo($str) {
    $bulan_inggris = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $bulan_indo = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return str_ireplace($bulan_inggris, $bulan_indo, $str);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan - MA Darul Fithrah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../assets/css/custom-admin.css?v=<?php echo time(); ?>">
    <style>
        .section-header { margin-bottom: 0px; padding-bottom: 5px; }
        .section-title { margin-bottom: 0; }
        .table-card { margin-top: 0; }
    </style>
</head>
<body>
    <div class="sidebar-overlay" onclick="document.querySelector('.sidebar').classList.remove('active'); document.querySelector('.sidebar-overlay').classList.remove('active');"></div>
    <div class="admin-container">
        <aside class="sidebar">
            <a href="#" class="brand">
                <img src="../assets/img/logo.png" alt="Logo">
                <div class="brand-text">
                    <span class="brand-title">MA Darul Fithrah</span>
                    <span class="brand-subtitle">Madrasah Aliyah</span>
                </div>
            </a>
            <ul class="nav-menu">
                <li>
                    <a href="dashboard.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="data-pendaftar.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
                        Pendaftar Baru
                    </a>
                </li>
                <li>
                    <a href="status-penerimaan.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
                        Status Penerimaan
                    </a>
                </li>
                <li>
                    <a href="data-siswa.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        Data Siswa
                    </a>
                </li>
                <li>
                    <a href="laporan.php" class="nav-link active">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        Laporan
                    </a>
                </li>
                <li>
                    <a href="arsip-data.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>
                        Arsip Data
                    </a>
                </li>
                <li>
                    <a href="ganti-password.php" class="nav-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        Ganti Password
                    </a>
                </li>
                <li>
                    <a href="logout.php" class="nav-link logout-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                        Logout
                    </a>
                </li>
            </ul>
        </aside>

        <main class="main-content">
            <header class="header">
                <button class="sidebar-toggle" onclick="document.querySelector('.sidebar').classList.add('active'); document.querySelector('.sidebar-overlay').classList.add('active');">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                </button>
                <div class="header-title">
                    <h1>Laporan</h1>
                    <p>Ringkasan dan tren data operasional</p>
                </div>
                <div class="header-actions">
                    <a class="btn btn-primary" href="cetak-laporan.php?periode=<?php echo $periode; ?>&kelas=<?php echo $kelas_filter; ?>" target="_blank">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 8px;"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                        Cetak Laporan
                    </a>
                </div>
            </header>


            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon bg-green">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                    </div>
                    <div>
                        <h2 class="stat-value"><?php echo $total_siswa_aktif; ?></h2>
                        <p class="stat-label">Total Siswa Aktif</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon bg-purple">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                    </div>
                    <div>
                        <h2 class="stat-value"><?php echo $total_pendaftar; ?></h2>
                        <p class="stat-label">Total Pendaftar</p>
                    </div>
                </div>
            </div>



            <div class="section-header">
                <div class="section-title">
                    Distribusi Siswa per Kelas <?php echo ($kelas_filter != 'Semua') ? "(Filter: $kelas_filter)" : ""; ?>
                </div>
            </div>
            <div class="table-card">
                <div class="table-scroll">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Kelas</th>
                                <th class="text-center">Jumlah Siswa</th>
                                <th class="text-center">Persentase</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($final_distribusi) > 0): ?>
                                <?php foreach ($final_distribusi as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['kelas']); ?></td>
                                        <td class="text-center"><?php echo $row['total']; ?></td>
                                        <td class="text-center">
                                            <?php 
                                            // Persentase dihitung dari total yang ditampilkan di tabel (total_terfilter)
                                            $persen = ($total_terfilter > 0) ? ($row['total'] / $total_terfilter) * 100 : 0;
                                            echo number_format($persen, 1) . '%'; 
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <tr style="background-color: #f9fafb; font-weight: 600;">
                                    <td>Total</td>
                                    <td class="text-center"><?php echo $total_terfilter; ?></td>
                                    <td class="text-center"><?php echo ($total_terfilter > 0) ? '100%' : '0%'; ?></td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="text-center" style="padding: 20px; color: #6b7280;">Tidak ada data siswa aktif.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>